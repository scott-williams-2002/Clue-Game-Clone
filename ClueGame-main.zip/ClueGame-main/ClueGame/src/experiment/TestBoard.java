package experiment;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * 
 * @author Calla Winner and Scott Williams
 * Description:
 * This class is a work in progress. It is meant to be the datastructure that stores the information for our
 * game board. It is comprised of a set of TestBoardCell, which store's one position's information. Not all the 
 * methods have been implemented yet. 
 *
 */
public class TestBoard {
	final static int ROWS_BOARD = 4, COLS_BOARD = 4;
	private Set<TestBoardCell> targets = new HashSet<>();
	private Set<TestBoardCell> visited = new HashSet<>();
	private TestBoardCell[][] grid = new TestBoardCell[ROWS_BOARD][COLS_BOARD];
	
	
	public TestBoard() {
		super();
		this.initBlank4x4Grid();
		
		// TODO Auto-generated constructor stub
	}
	
	
	// initializes grid and creates the adj matrix for all cells
	private void initBlank4x4Grid() {
		// build blank grid
		TestBoardCell cell;
		for (int r = 0; r < ROWS_BOARD; r++) {
			for (int c = 0; c < COLS_BOARD; c++) {
				cell = new TestBoardCell(r,c);
				this.grid[r][c] = cell;
			}
		}
		
		
		//Must do 2 separate for loops so that the adj matrix can "see" cells below it
		
		// for every cell in grid, set the adj matrix
		for (int r = 0; r < ROWS_BOARD; r++) {
			for (int c = 0; c < COLS_BOARD; c++) {
				this.grid[r][c].setAdjMtx(calcAdjInBoard(r,c));
			}
		}
	}
	
	// builds and returns adjMatrix of TestBoardCells, only to be used in building the TestBoard obj
	private Set<TestBoardCell> calcAdjInBoard(int r, int c) {
		
		Set<TestBoardCell> adjMtx = new HashSet<>(); // Contains all cells adjacent to this cell
		if (r != 0) {
			adjMtx.add(this.getCell(r - 1, c));
		}
		if (c != 0) {
			adjMtx.add(this.getCell(r, c - 1));
		}
		if (r != TestBoard.ROWS_BOARD - 1) {
			adjMtx.add(this.getCell(r + 1, c ));
		}
		if (c != TestBoard.COLS_BOARD - 1) {
			adjMtx.add(this.getCell(r, c + 1 ));
		}
		return adjMtx;
	} // end calcAdjInBoard

	
	// Calculates the legal targets for a move from startCell of length pathLength
	public void calcTargets(TestBoardCell startCell, int pathlength){
		visited.clear();
		targets.clear();
		visited.add(startCell);
		findAllTargets(startCell, pathlength);
	}
	
	// recursive function for calcTargets
	public void findAllTargets(TestBoardCell thisCell, int numSteps) {
		for (TestBoardCell adjCell : thisCell.getAdjMtx()) {
			// if already in visited list, skip rest of this 
			if (visited.contains(adjCell) || adjCell.getOccupied()) {
				continue; //skip
			} 
			
			//add adjCell to visited list
			visited.add(adjCell);
			
			//if numSteps == 1, add adjCell to Targets 
			if (numSteps == 1 ||  adjCell.getRoom()) { // or next cell is a (unoccupied) room, add to targets
				targets.add(adjCell);
			}
			else {// else call findAllTargets() with adjCell, numSteps-1 
				findAllTargets(adjCell, numSteps - 1);
			}
			//remove adjCell from visited list 
			visited.remove(adjCell);
		}
	}
	
	// returns cell from the board at inputed row/col
	public TestBoardCell getCell(int row, int col) {
		return  this.grid[row][col]; // the cell in the grid
	}
	
	// returns the set of all possible targets
	public Set<TestBoardCell> getTargets(){
		return targets;
	}
	
	//
}
