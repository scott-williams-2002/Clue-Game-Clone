package experiment;


import java.util.HashSet;
import java.util.Set;

import org.junit.Assert;

//Represents 1 cell in the grid
public class TestBoardCell {
	private int row;
	private int col;
	private boolean isRoom;
	private boolean isOccupied;
	private Set<TestBoardCell> adjMtx = new HashSet<>(); // Contains all cells adjacent to this cell
	
	public TestBoardCell(int row, int col) {
		super();
		this.row = row;
		this.col = col;
		
	}
	
	public Set<TestBoardCell> getAdjMtx() {
		return adjMtx;
	}

	public void setAdjMtx(Set<TestBoardCell> adjMtx) {
		this.adjMtx = adjMtx;
	}
	
	@Override
	public String toString() {
		return "TestBoardCell [row=" + row + ", col=" + col + "]";
	}

	// sets if this cell is a part of a room
	public void setRoom(boolean isRoom) { // made public for testing
		this.isRoom = isRoom;
	}
	// returns if the cell is apart of a room
	public boolean getRoom() { // made public for testing
		return isRoom;
	}
	
	// sets if this cell is occupied by a player
	public void setOccupied(boolean isOccupied) {         // made public for testing
		this.isOccupied = isOccupied;
	}
	
	// returns true if the cell is occupied by a player
	public boolean getOccupied() { // made public for testing
		return isOccupied;
	}
	
	
}
