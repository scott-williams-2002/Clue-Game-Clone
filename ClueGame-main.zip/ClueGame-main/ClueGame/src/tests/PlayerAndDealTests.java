package tests;

/*
 * This program tests that config files are loaded properly.
 */

// Doing a static import allows me to write assertEquals rather than
// Assert.assertEquals
import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import clueGame.*;

public class PlayerAndDealTests{
	private static Board board;
	@BeforeAll
	public static void setUp() {
		board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
		board.initialize();

	}
	@Test
	public void playerSetIsCorrect() {
		
		// each ensures that the player was loaded correctly into deal
		int[] scottStartLoc = {28, 17};
		Player scott = new HumanPlayer("Compsci Scott", "Green", scottStartLoc);
		assertTrue(board.playersSetContains(scott));

		int[] pcjStartLoc = {14, 2};
		Player pcj = new ComputerPlayer("President PCJ", "Purple", pcjStartLoc);
		assertTrue(board.playersSetContains(pcj));

		int[] howardStartLoc = {0, 17};
		Player howard = new ComputerPlayer("Director Howard", "Red", howardStartLoc);
		assertTrue(board.playersSetContains(howard));
		
	}
	@Test
	public void testSolutionDifferingTypes(){
		// Didn't want to return solution as public method, hence the solutionIsVaildMeathod
		assertTrue(board.solutionIsValid());
	}
	
	@Test
	public void dealValidTest(){
		Set<Player> playersSet = board.getPlayersSet();
		Set<Card> cardSet = new HashSet();
		
		for (Player player: playersSet) {
			cardSet.addAll(player.getPlayerCards());
			
			assertTrue(player.getPlayerCards().size() == 2 || player.getPlayerCards().size() == 3);
		}
		
		// make sure there are no duplicates and all cards are dealt
		assertTrue(cardSet.size() == 21 -3 );
		
		
	}

}





