package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import clueGame.Board;
import clueGame.BoardCell;
import clueGame.Card;
import clueGame.CardType;
import clueGame.ComputerPlayer;
import clueGame.HumanPlayer;
import clueGame.Player;
import experiment.TestBoard;
import experiment.TestBoardCell;

public class GameSolutionTest { 
	private static Board board;
	@BeforeAll
	public static void setUp() {
		board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
		board.initialize();
		
		
	}
	
	@Test
	public void testCheckAccusation() {
		// tests that if the given solution is entered into the checkAccusation() method, it will return true
		Card solutionPerson = new Card("Scott", CardType.PERSON);
		Card solutionWeapon = new Card("Computer Charger", CardType.WEAPON);
		Card solutionRoom = new Card("CTLM", CardType.ROOM);
		
		Card[] solution = {solutionPerson, solutionWeapon, solutionRoom};
		board.setSolution(solution);
		assertTrue(board.checkAccusation(solution));
		
		// wrong cards for testing
		Card wrongPerson = new Card("Not Scott", CardType.PERSON);
		Card wrongWeapon = new Card("Not Computer Charger", CardType.PERSON);
		Card wrongRoom = new Card("Not CTLM", CardType.PERSON);
		
		// creates 3 possible solutions with one wrong person,weapon, or room
		Card[] solutionWrongPerson = {wrongPerson, solutionWeapon, solutionRoom};
		Card[] solutionWrongWeapon = {solutionPerson, wrongWeapon, solutionRoom};
		Card[] solutionWrongRoom = {solutionPerson, solutionWeapon, wrongRoom};
		
		assertFalse(board.checkAccusation(solutionWrongPerson));
		assertFalse(board.checkAccusation(solutionWrongWeapon));
		assertFalse(board.checkAccusation(solutionWrongRoom));
	}
	
	// this method creates 3 players and handles 3 cases where each player has to disprove the suggestion
	@Test
	public void testDisproveSuggestion() {
		Card suggestedPerson = new Card("PCJ", CardType.PERSON);
		Card suggestedWeapon = new Card("Hit and Run", CardType.WEAPON);
		Card suggestedRoom = new Card("CoorsTek", CardType.ROOM);
		
		Card[] suggestion = {suggestedPerson, suggestedWeapon, suggestedRoom};
		
		// creating Players with 0, 1, and 2 cards in common with suggestion
		int[] location = {0,0};
		Player playerZeroCommon = new ComputerPlayer("PlayerZero", "Red", location);
		Player playerOneCommon = new ComputerPlayer("PlayerOne", "Green", location);
		Player playerTwoCommon = new ComputerPlayer("PlayerTwo", "Blue", location);
		
		// tests that player suggestion with 0 common cards returns null
		playerZeroCommon.updateHand(new Card("Scott", CardType.PERSON));
		playerZeroCommon.updateHand(new Card("Grenade", CardType.WEAPON));
		playerZeroCommon.updateHand(new Card("StudyRoom", CardType.ROOM));
		assertEquals(playerZeroCommon.disproveSuggestion(suggestion), null);
		
		// tests that player suggestion with 1 common card returns the common card
		playerOneCommon.updateHand(new Card("Scott", CardType.PERSON));
		playerOneCommon.updateHand(new Card("Grenade", CardType.WEAPON));
		playerOneCommon.updateHand(suggestedRoom);
		assertEquals(playerOneCommon.disproveSuggestion(suggestion), suggestedRoom);
		
		//tests that player suggestion with 2 common card returns
		// one randomly selected card in common
		playerTwoCommon.updateHand(new Card("Scott", CardType.PERSON));
		playerTwoCommon.updateHand(suggestedWeapon);
		playerTwoCommon.updateHand(suggestedRoom);
		Card randomlySelectedCommonCard = playerTwoCommon.disproveSuggestion(suggestion);
		
		// weird test case here but since were picking one of two
		// at random I needed to use a conditional for the or case
		// and assert true if the conditional is true. 
		// If the conditional is false it will assert false 
		if(randomlySelectedCommonCard.equals(suggestedWeapon) || randomlySelectedCommonCard.equals(suggestedRoom)) {
			assertTrue(true);
		}
		else {
			assertTrue(false);
		}
	}
	
	// tests the handle suggestion method for all people
	public void testHandleSuggestion() {
		// suggestion that no player can disprove
		Card suggestedPerson = new Card("NullPerson", CardType.PERSON);
		Card suggestedWeapon = new Card("NullWeapon", CardType.WEAPON);
		Card suggestedRoom = new Card("NullRoom", CardType.ROOM);
		
		int[] location = {0,0};
		Player suggestingPlayer = new ComputerPlayer("suggestor", "Red", location );
		Card[] suggestionNoDisproving = {suggestedPerson, suggestedWeapon, suggestedRoom};
		assertEquals(board.handleSuggestion(suggestionNoDisproving, suggestingPlayer), null);
		
		// tests with 3 players that have cards that cant disprove suggestion but suggestor can
		Player notDisprovingSuggestionOne = new ComputerPlayer("playerOne", "Green", location);
		Player notDisprovingSuggestionTwo = new ComputerPlayer("playerTwo", "Blue", location);
		Player notDisprovingSuggestionThree = new ComputerPlayer("playerTwo", "Orange", location);
		
		Card notDisprovingPlayerCard = new Card("Student", CardType.PERSON);
		Card notDisprovingWeaponCard = new Card("Backpack", CardType.WEAPON);
		Card notDisprovingRoomCard = new Card("Elm", CardType.ROOM);
		
		notDisprovingSuggestionOne.updateHand(notDisprovingPlayerCard);
		notDisprovingSuggestionOne.updateHand(notDisprovingWeaponCard);
		notDisprovingSuggestionOne.updateHand(notDisprovingRoomCard);
		
		notDisprovingSuggestionTwo.updateHand(notDisprovingPlayerCard);
		notDisprovingSuggestionTwo.updateHand(notDisprovingWeaponCard);
		notDisprovingSuggestionTwo.updateHand(notDisprovingRoomCard);
		
		notDisprovingSuggestionThree.updateHand(notDisprovingPlayerCard);
		notDisprovingSuggestionThree.updateHand(notDisprovingWeaponCard);
		notDisprovingSuggestionThree.updateHand(notDisprovingRoomCard);
		
		Set<Player> playersCantDispute = new HashSet<>();
		playersCantDispute.add(notDisprovingSuggestionOne);
		playersCantDispute.add(notDisprovingSuggestionTwo);
		playersCantDispute.add(notDisprovingSuggestionThree);
		
		board.setPlayersSet(playersCantDispute);
		Card testTwoOutput = board.handleSuggestion(suggestionNoDisproving, suggestingPlayer);
		assertEquals(testTwoOutput, null);
		
		
		
		// tests that if the player is the only one that can disprove suggestion, 
		// then that card responsible is returned by handle suggestion
		Player canDisprovePlayer = new HumanPlayer("Calla", "Purple", location);
		Card humanCardPerson = new Card("Mister Clean", CardType.PERSON);
		Card humanCardWeapon = suggestedWeapon;
		Card humanCardRoom = new Card("Dining Hall", CardType.ROOM);
		
		canDisprovePlayer.updateHand(humanCardPerson);
		canDisprovePlayer.updateHand(humanCardWeapon);
		canDisprovePlayer.updateHand(humanCardRoom);
		
		Set<Player> playersWithHuman = playersCantDispute;
		playersWithHuman.add(canDisprovePlayer); // adds the human to old set of players that can't dispute
		board.setPlayersSet(playersWithHuman);
		Card testThreeOutput = board.handleSuggestion(suggestionNoDisproving, notDisprovingSuggestionThree);
		assertEquals(testThreeOutput, humanCardWeapon); // humanCardWeapon is the card in human's deck that is in common with suggestion
		
		
		//final test ensures the correct order of outputted 
		// card after calling handle suggestion method
		// same information in player set from 3rd test above
		// only difference is the last player can disprove
		// the suggestion, but the method return should be 
		// the same as the third test's return
		
		Player alsoCanDisprovePlayer = new ComputerPlayer("Prof", "grey", location);
		// player cards. person will be the same as suggestion's person
		Card alsoCanDisprovePlayerPerson = suggestedPerson;
		Card alsoCanDisprovePlayerWeapon = new Card("Chain", CardType.WEAPON);
		Card alsoCanDisprovePlayerRoom = new Card("bathroom", CardType.ROOM);
		
		alsoCanDisprovePlayer.updateHand(alsoCanDisprovePlayerPerson);
		alsoCanDisprovePlayer.updateHand(alsoCanDisprovePlayerWeapon);
		alsoCanDisprovePlayer.updateHand(alsoCanDisprovePlayerRoom);
		
		// adds last player to existing set of players
		playersWithHuman.add(alsoCanDisprovePlayer);
		
		board.setPlayersSet(playersWithHuman);
		board.handleSuggestion(suggestionNoDisproving, notDisprovingSuggestionThree);
		
		Card testFourOutput = board.handleSuggestion(suggestionNoDisproving, notDisprovingSuggestionThree);
		assertTrue(testFourOutput.equals(humanCardWeapon)); // should return first disproving player's card due to propper game play order
		
	}
	
}
