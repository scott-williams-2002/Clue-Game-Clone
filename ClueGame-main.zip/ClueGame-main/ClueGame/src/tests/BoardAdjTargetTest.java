package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import clueGame.Board;
import clueGame.BoardCell;
import experiment.TestBoard;
import experiment.TestBoardCell;

public class BoardAdjTargetTest { 
	private static Board board;
	@BeforeAll
	public static void setUp() {
		board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
		board.initialize();
	}
	
	@Test
	public void walkwayAdj() {
		//Locations with only walkways as adjacent locations
		// Cell(17, 16)
		Set<BoardCell> adjMtrx = board.getAdjList(17, 17);
		assertEquals(adjMtrx.size(), 4);
		for (BoardCell adjCell : adjMtrx) { // for every cell in adj matrix, make sure its a walkway
			assertEquals(adjCell.getInitial(), "W");
		}
		assertTrue(adjMtrx.contains(board.getCell(17, 16))); // left
		assertTrue(adjMtrx.contains(board.getCell(17, 18))); // right
		assertTrue(adjMtrx.contains(board.getCell(16, 17))); // up
		assertTrue(adjMtrx.contains(board.getCell(18, 17))); // down

		// Cell(15, 7)
		adjMtrx = board.getAdjList(15, 7);
		assertEquals(adjMtrx.size(), 4);
		for (BoardCell adjCell : adjMtrx) { // for every cell in adj matrix, make sure its a walkway
			assertEquals(adjCell.getInitial(), "W");
		}
		assertTrue(adjMtrx.contains(board.getCell(14, 7))); // left
		assertTrue(adjMtrx.contains(board.getCell(16, 7))); // right
		assertTrue(adjMtrx.contains(board.getCell(15, 8))); // up
		assertTrue(adjMtrx.contains(board.getCell(15, 6))); // down	
	}
	
	@Test
	public void locWithInRoomAndEdgesAdj() {
		// Locations within room (not center)
		Set<BoardCell> adjMtrx = adjMtrx = board.getAdjList(4, 2); // Guggenheim
		assertEquals(adjMtrx.size(), 0); // empty
		
		adjMtrx = board.getAdjList(12, 11); // CoorsTek
		assertEquals(adjMtrx.size(), 0); // empty
		
		adjMtrx = board.getAdjList(3, 21); // Green Center
		assertEquals(adjMtrx.size(), 0); // empty
		
		adjMtrx = board.getAdjList(3, 21); // Green Center
		assertEquals(adjMtrx.size(), 0); // empty
		
		adjMtrx = board.getAdjList(28, 3); // Brown Building
		assertEquals(adjMtrx.size(), 0); // empty
		
		adjMtrx = board.getAdjList(23, 28); // Marquez
		assertEquals(adjMtrx.size(), 0); // empty
		
		
		// locations at each edge of the board 
		
		// left side (also beside room cell that is not doorway)
		adjMtrx = board.getAdjList(8, 0);
		assertEquals(adjMtrx.size(), 1); // only one adjacency
		assertTrue(adjMtrx.contains(board.getCell(8, 1)));
		
		//top
		adjMtrx = board.getAdjList(0, 19);
		assertEquals(adjMtrx.size(), 2); // 2 adj cells
		assertTrue(adjMtrx.contains(board.getCell(1, 19)));
		assertTrue(adjMtrx.contains(board.getCell(0, 20)));
		
		// right side (also beside room cell that is not doorway)
		adjMtrx = board.getAdjList(11, 28);
		assertEquals(adjMtrx.size(), 2); // 2 adj cells
		assertTrue(adjMtrx.contains(board.getCell(11, 27)));
		assertTrue(adjMtrx.contains(board.getCell(12, 28)));
		
		// bottom
		adjMtrx = board.getAdjList(28, 18);
		assertEquals(adjMtrx.size(), 3); // 3 adj cells
		assertTrue(adjMtrx.contains(board.getCell(27, 18)));
		assertTrue(adjMtrx.contains(board.getCell(28, 17)));
		assertTrue(adjMtrx.contains(board.getCell(28, 19)));
		
		// beside a room cell that is not a doorway
		adjMtrx = board.getAdjList(17, 15);
		assertEquals(adjMtrx.size(), 3); // 3 adj cells
		assertTrue(adjMtrx.contains(board.getCell(16, 15)));
		assertTrue(adjMtrx.contains(board.getCell(17, 16)));
		assertTrue(adjMtrx.contains(board.getCell(17, 14)));
	}
	
	@Test
	public void doorwayAdj(){
		//Locations that are doorways
		
		// walkway into Guggemheim
		Set<BoardCell> adjMtrx = adjMtrx = board.getAdjList(3, 5);
		//assertEquals(adjMtrx.size(), 4); // 4 adj cells
		assertTrue(adjMtrx.contains(board.getCell(3, 2))); // contains center cell of GU
		assertTrue(adjMtrx.contains(board.getCell(2, 5)));
		assertTrue(adjMtrx.contains(board.getCell(4, 5)));
		assertTrue(adjMtrx.contains(board.getCell(3, 6)));
		
		// walkway into CoorsTek
		adjMtrx = board.getAdjList(11, 17);
		assertEquals(adjMtrx.size(), 4); // 4 adj cells
		assertTrue(adjMtrx.contains(board.getCell(12, 12))); // contains center cell of CoorsTek
		
		// walkway into Green Center
		adjMtrx = board.getAdjList(4, 26);
		assertEquals(adjMtrx.size(), 3); // 4 adj cells
		assertTrue(adjMtrx.contains(board.getCell(8, 23))); // contains center cell of Green Center
	}
	
	@Test
	public void centerAdj() {
		// Testing center cells 
		
		//Guggenheim (with secret passage to CTLM)
		Set<BoardCell> adjMtrx = adjMtrx = board.getAdjList(3, 2); // center cell of GU
		assertEquals(adjMtrx.size(), 2); // 2 adj cells
		assertTrue(adjMtrx.contains(board.getCell(3, 5))); // the doorway
		assertTrue(adjMtrx.contains(board.getCell(26, 24))); // CoorsTek center room
		
		//CoorsTek (With secret passage to GU)
		adjMtrx = board.getAdjList(26, 24); // center cell of CoorsTek
		assertEquals(adjMtrx.size(), 2); // 2 adj cells
		assertTrue(adjMtrx.contains(board.getCell(24, 22))); // the doorway
		assertTrue(adjMtrx.contains(board.getCell(3, 2))); // GU center room
		
		
		//Brown Building (With secret passage to GR)
		adjMtrx = board.getAdjList(23, 2); 
		assertEquals(adjMtrx.size(), 5); // 4 doorways and GR
		assertTrue(adjMtrx.contains(board.getCell(8, 23))); // Green center room
		
		//Green Center (With secret passage to BB)
		adjMtrx = board.getAdjList(8, 23); 
		assertEquals(adjMtrx.size(), 5); // 4 doorways and BB
		assertTrue(adjMtrx.contains(board.getCell(23, 2))); // Brown B. center room
		
		// Kafadar center room
		adjMtrx = board.getAdjList(3, 12); // center cell of Kafadar
		assertEquals(adjMtrx.size(), 5); // 5 doorways
		assertTrue(adjMtrx.contains(board.getCell(7, 12)));
		
		//Alderson
		adjMtrx = board.getAdjList(20, 14); // center cell
		assertEquals(adjMtrx.size(), 2); // 2 doorways
		assertTrue(adjMtrx.contains(board.getCell(28, 8)));
		assertTrue(adjMtrx.contains(board.getCell(18, 12)));
	}
	
	// tests targets are correct on the walkway for 1,2,3 rolls
	@Test
	public void testTargetsWalkway() {
		//testing for a roll of 1 at position (9,2)
		board.calcTargets(board.getCell(9, 2), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(8, 2)));
		assertTrue(targets.contains(board.getCell(10, 2)));	
		assertTrue(targets.contains(board.getCell(9, 3)));	
		
		//testing for a roll of 2 at position (9,2)
		board.calcTargets(board.getCell(9, 2), 2);
		targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(8, 1)));
		assertTrue(targets.contains(board.getCell(10, 3)));	
		assertTrue(targets.contains(board.getCell(8, 3)));	
		
		//testing for a roll of 3 at position (9,2)
		board.calcTargets(board.getCell(9, 2), 3);
		targets= board.getTargets();
		assertEquals(5, targets.size());
		assertTrue(targets.contains(board.getCell(8, 0)));
		assertTrue(targets.contains(board.getCell(8, 2)));
		assertTrue(targets.contains(board.getCell(8, 4)));
		assertTrue(targets.contains(board.getCell(9, 3)));	
		assertTrue(targets.contains(board.getCell(10, 2)));
	}
	
	//tests for targets when player is entering a room for 1,2,3 rolls
	@Test
	public void testEnteringRoom() {
		// starting at (3,6) and rolling a 1
		board.getCell(3, 2).setOccupied(false);
		board.getCell(3, 12).setOccupied(false);
		board.calcTargets(board.getCell(3, 6), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(3, targets.size());
		assertTrue(targets.contains(board.getCell(2, 6)));
		assertTrue(targets.contains(board.getCell(3, 5)));	
		assertTrue(targets.contains(board.getCell(3, 7)));	
		
		// starting at (2,6) and rolling a 2
		board.calcTargets(board.getCell(2, 6), 2);
		targets= board.getTargets();
		assertEquals(4, targets.size());
		assertTrue(targets.contains(board.getCell(1, 5)));
		assertTrue(targets.contains(board.getCell(1, 7)));	
		assertTrue(targets.contains(board.getCell(3, 5)));	
		assertTrue(targets.contains(board.getCell(3, 7)));	
		
		// starting at (1,7) and rolling a 3
		board.calcTargets(board.getCell(1, 7), 3);
		targets= board.getTargets();
		assertEquals(4, targets.size());
		assertTrue(targets.contains(board.getCell(2, 5)));
		assertTrue(targets.contains(board.getCell(3, 12)));	
		assertTrue(targets.contains(board.getCell(3, 6)));	
	}
	
	// tests that size of targets is correct and that outside of the room has specific target cells
	@Test
	public void testLeavingRoomDoor() {
		// starting at (3,2) and rolling a 1
		board.calcTargets(board.getCell(3, 2), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCell(3, 5)));  //target outside room
		
		// starting at (3,2) and rolling a 2
		board.calcTargets(board.getCell(3, 2), 2);
		targets= board.getTargets();
		assertEquals(4, targets.size());
		assertTrue(targets.contains(board.getCell(2, 5)));//target outside room
		assertTrue(targets.contains(board.getCell(4, 5)));//target outside room
		assertTrue(targets.contains(board.getCell(3, 6)));//target outside room
		
		// starting at (3,2) and rolling a 3
		board.calcTargets(board.getCell(3, 2), 3);
		targets= board.getTargets();
		assertEquals(5, targets.size());
		assertTrue(targets.contains(board.getCell(1, 5))); //targets outside room
		assertTrue(targets.contains(board.getCell(5, 5)));	
		assertTrue(targets.contains(board.getCell(2, 6)));
	}
	
	// tests that size of targets is correct and that the new room is in targets
	@Test
	public void testLeavingRoomPassage() {
		// starting at (3,2) and rolling a 1
		board.calcTargets(board.getCell(3, 2), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCell(26, 24)));  //target in other room
		
		// starting at (3,2) and rolling a 2
		board.calcTargets(board.getCell(3, 2), 2);
		targets= board.getTargets();
		assertEquals(4, targets.size());
		assertTrue(targets.contains(board.getCell(26, 24)));  //target in other room

		// starting at (3,2) and rolling a 3
		board.calcTargets(board.getCell(3, 2), 3);
		targets= board.getTargets();
		assertEquals(5, targets.size());
		assertTrue(targets.contains(board.getCell(26, 24)));  //target in other room
	}
	
	//tests the correct and correct number of cells in targets if some potential targets are blocked
	@Test 
	public void testTargetsBlocked() {
		// starting at (0,5) door and rolling a 1, no possible moves
		board.getCell(1, 5).setOccupied(true);   // sets the center cell as occupied
		board.calcTargets(board.getCell(0, 5), 1);
		Set<BoardCell> targets = board.getTargets();
		assertEquals(1, targets.size());
		board.getCell(1, 5).setOccupied(false);
		
		// starting at (1,5) and rolling a 2
		board.getCell(3, 5).setOccupied(true);
		board.calcTargets(board.getCell(1, 5), 2);
		targets= board.getTargets();
		assertEquals(2, targets.size());
		assertTrue(targets.contains(board.getCell(2, 6)));
		board.getCell(3, 5).setOccupied(false);
		
		// starting at (5,7) and rolling a 3
		board.getCell(3, 6).setOccupied(true);
		board.calcTargets(board.getCell(5, 7), 3);
		targets= board.getTargets();
		assertEquals(6, targets.size());
		assertTrue(targets.contains(board.getCell(7, 6)));
		assertTrue(targets.contains(board.getCell(7, 8)));
		assertTrue(targets.contains(board.getCell(8, 7)));
		board.getCell(3, 6).setOccupied(false);
	}
	
}
