package tests;

import clueGame.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import experiment.TestBoard;
import experiment.TestBoardCell;

// find all possible rooms needs to not be null
// in this test method need to enter all possible rooms as an input
// in player.setallpossible rooms 

//^^^^^^^^^^^
//^^^^^^^^^^^





public class ComputerAITest { 
	private static Board board;
	private static Set<Card> possibleWeapons;
	private static Card weaponOne;
	private static Card weaponTwo;
	private static Card weaponThree;
	private static Card weaponFour;
	private static Card weaponFive;
	private static Card weaponSix;
	private static Set<Card> possiblePeople;
	private static Card personOne;
	private static Card personTwo;
	private static Card personThree;
	private static Card personFour;
	private static Set<Card> possibleRoom;
	private static Card coorsCard;
	private static Card greenCard;
	private static Card kafadarCard;
	private static Card aldersonCard;
	private static Card guggenhiemCard;
	private static ClueGame window;
	@BeforeAll
	public static void setUp() {
		board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
		board.initialize();
		board.setWindow();
		window = board.getWindow();
		
	}
	
	@BeforeAll 
	public static void populateAllPossibleStaticVariables(){
		
		// build all possible 
		possibleWeapons = new HashSet<>();
		weaponOne = new Card("Under-cooked Chicken", CardType.WEAPON);
		weaponTwo = new Card("Registration Hold", CardType.WEAPON);
		weaponThree = new Card("Coding Standards Violation", CardType.WEAPON);
		weaponFour = new Card("Computer Charger", CardType.WEAPON);
		weaponFive = new Card("Hit and Run", CardType.WEAPON);
		weaponSix = new Card("Stern Lecture", CardType.WEAPON);


		possibleWeapons.add(weaponOne);
		possibleWeapons.add(weaponTwo);
		possibleWeapons.add(weaponThree);
		possibleWeapons.add(weaponFour);
		possibleWeapons.add(weaponFive);
		possibleWeapons.add(weaponSix);

		
		
		Player.setAllPossibleWeapons(possibleWeapons);
		
		possiblePeople = new HashSet<>();
		personOne = new Card("Scott", CardType.PERSON);
		personTwo = new Card("Calla", CardType.PERSON);
		personThree = new Card("PCJ", CardType.PERSON);
		personFour = new Card("Jim", CardType.PERSON);


		possiblePeople.add(personOne);
		possiblePeople.add(personTwo);
		possiblePeople.add(personThree);
		possiblePeople.add(personFour);
		
		Player.setAllPossiblePeople(possiblePeople);
		
		possibleRoom = new HashSet<>();
		coorsCard = new Card("CoorsTek", CardType.ROOM);
		greenCard = new Card("Green Center", CardType.ROOM);
		kafadarCard = new Card("Kafadar", CardType.ROOM);
		aldersonCard = new Card("Alderson Hall", CardType.ROOM);
		guggenhiemCard = new Card("Guggenheim", CardType.ROOM);
		
		possibleRoom.add(coorsCard);
		possibleRoom.add(greenCard);
		possibleRoom.add(kafadarCard);
		possibleRoom.add(aldersonCard);
		
		Player.setAllPossibleRooms(possibleRoom);
	}

	public void testComputerGeneratedSolutions() {
		
		int[] startLoc = {26,24}; //centercell location for coorstek
		Player aiOne = new ComputerPlayer("aiOne", "Brown", startLoc);

		// player starts in coorstek room
		String roomName = "CoorsTek";
		Card[] suggestionOne = aiOne.createSuggestion(roomName);
		String suggestionRoomName = "";
		for(Card suggestedCard :suggestionOne) {
			if(suggestedCard.getCardType().equals(CardType.ROOM)) {
				suggestionRoomName = suggestedCard.getCardName();
				break;
			}
		}
		assertEquals(roomName, suggestionRoomName);


		// if computer has only one weapon it has not encountered, select as suggestion

		// difference between seencards and possible for weapons is 1 return aggregate
		
		// Player ai2 has Fire in hand and has seen Mace and Chainsaw
		Player aiTwo = new ComputerPlayer("aiTwo", "Blue", startLoc);
		aiTwo.setWeaponCards(possibleWeapons);

		Card aiTwoRoomCard = new Card("Room", CardType.ROOM);
		Card aiTwoPersonCard = new Card("Person", CardType.PERSON);
		Card aiTwoWeaponCard = weaponFour;

		aiTwo.updateHand(aiTwoPersonCard);
		aiTwo.updateHand(aiTwoWeaponCard);
		aiTwo.updateHand(aiTwoRoomCard);

		aiTwo.updateSeen(weaponOne);
		aiTwo.updateSeen(weaponTwo);
		aiTwo.updateSeen(weaponFive);
		aiTwo.updateSeen(weaponSix);


		// should return weapon 3 because its not in player deck and not in seen
		Card[] suggestionTwo = aiTwo.createSuggestion("Room");
		String weaponName = "Coding Standards Violation";
		String suggestionWeaponName = "";
		for(Card suggestedCard :suggestionTwo) {
			if(suggestedCard.getCardType().equals(CardType.WEAPON)) {
				suggestionWeaponName = suggestedCard.getCardName();
				break;
			}
		}
		assertEquals(weaponName, suggestionWeaponName);

		// if computer has only one person it has not encountered, select as suggestion
		// same test as before but for person cards
		
		// difference between seencards and possible for weapons is 1 return aggregate
		Player aiThree = new ComputerPlayer("aiThree", "Orange", startLoc);
		aiThree.setPersonCards(possiblePeople); //sets possible people in player

		Card aiThreeRoomCard = new Card("Room", CardType.ROOM);
		Card aiThreePersonCard = personFour;
		Card aiThreeWeaponCard = new Card("Weapon", CardType.WEAPON);

		aiThree.updateHand(aiThreePersonCard);
		aiThree.updateHand(aiThreeWeaponCard);
		aiThree.updateHand(aiThreeRoomCard);

		aiThree.updateSeen(personOne);
		aiThree.updateSeen(personTwo);

		// should return person 3 because its not in player deck and not in seen
		Card[] suggestionThree = aiThree.createSuggestion("room");
		String personName = "PCJ";
		String suggestionPersonName = "";
		for(Card suggestedCard :suggestionThree) {
			if(suggestedCard.getCardType().equals(CardType.PERSON)) {
				suggestionPersonName = suggestedCard.getCardName();
			}
		}
		assertEquals(personName, suggestionPersonName);

		// Tests for multiple weapons not seen same as before except for assertion logic
		// if computer has only one weapon it has not encountered, select as suggestion
		// uses same cards as prior tests	
		// difference between seencards and possible for weapons is 1 return aggregate
		Player aiFour = new ComputerPlayer("aiFour", "Blue", startLoc);
		aiFour.setWeaponCards(possibleWeapons);

		Card aiFourRoomCard = new Card("Room", CardType.ROOM);
		Card aiFourPersonCard = new Card("Person", CardType.PERSON);
		Card aiFourWeaponCard = weaponFour;

		aiFour.updateHand(aiFourPersonCard);
		aiFour.updateHand(aiFourWeaponCard);
		aiFour.updateHand(aiFourRoomCard);

		// only sees one this test
		aiFour.updateSeen(weaponOne);

		// should return weapon 3 because its not in player deck and not in seen
		Card[] suggestionFour = aiFour.createSuggestion("room");
		String weaponNameOne = "Chainsaw";
		String weaponNameTwo = "PlasticBag";
		String suggestionWeaponNameMultiple = "";
		for(Card suggestedCard :suggestionFour) {
			if(suggestedCard.getCardType().equals(CardType.WEAPON)) {
				suggestionWeaponNameMultiple = suggestedCard.getCardName();
			}
		}

		// asserts if not seen either potential cards in suggestion
		if(suggestionWeaponNameMultiple.equals(weaponNameOne) || suggestionWeaponNameMultiple.equals(weaponNameTwo)) {
			assertTrue(true);
		}
		else {
			assertTrue(false);
		}

		// if computer has only one person it has not encountered, select as suggestion
		// same test as before but for person cards

		// difference between seencards and possible for weapons is 1 return aggregate
		Player aiFive = new ComputerPlayer("aiFive", "Orange", startLoc);
		aiFive.setPersonCards(possiblePeople); //sets possible people in player

		Card aiFiveRoomCard = new Card("Room", CardType.ROOM);
		Card aiFivePersonCard = personFour;
		Card aiFiveWeaponCard = new Card("Weapon", CardType.WEAPON);

		aiFive.updateHand(aiFivePersonCard);
		aiFive.updateHand(aiFiveWeaponCard);
		aiFive.updateHand(aiFiveRoomCard);

		aiFive.updateSeen(personOne);
		aiFive.updateSeen(personTwo);

		// should return person 3 because its not in player deck and not in seen
		Card[] suggestionFive = aiFive.createSuggestion("Room");
		String personNameOne = "Calla";
		String personNameTwo = "PCJ";
		String suggestionPersonNameMultiple = "";
		for(Card suggestedCard :suggestionFive) {
			if(suggestedCard.getCardType().equals(CardType.PERSON)) {
				suggestionPersonNameMultiple = suggestedCard.getCardName();
			}
		}
		// asserts if not seen either potential cards in suggestion
		if(suggestionPersonNameMultiple.equals(personNameOne) || suggestionPersonNameMultiple.equals(personNameTwo)) {
			assertTrue(true);
		}
		else {
			assertTrue(false);
		}
	}
	
	@Test
	public void testComputerGeneratedTarget() {
		
		//AI ONE
		
		//testing for a roll of 1 at position (9,2)
		board.calcTargets(board.getCell(9, 2), 1);
		Set<BoardCell> targets= board.getTargets();
		assertEquals(3, targets.size());
		
		int[] startLocOne = {9,2}; //Starting position for test
		Player aiOne = new ComputerPlayer("aiOne", "Brown", startLocOne);
		
		// have computer choose a target
		BoardCell aiOneSelectedTarget= aiOne.selectTarget(targets);
		
		// Selected target should be one of the targets
		// Because there isn't a room as a target, it should be random...
		// ensure that computer chooses one of these as targets (all hallway targets)
		assertTrue(aiOneSelectedTarget.equals(board.getCell(8, 2))|| aiOneSelectedTarget.equals(board.getCell(10, 2)) || aiOneSelectedTarget.equals(board.getCell(9, 3)));
		
		
		//AI TWO		
		// should enter Kafadar
		// starting at (1,7) and rolling a 3
		board.calcTargets(board.getCell(1, 7), 3);
		targets= board.getTargets();
		assertEquals(4, targets.size());
		
		int[] startLocTwo = {1,7}; //Starting position for test
		Player aiTwo = new ComputerPlayer("aiTwo", "Pink", startLocTwo);
		
		// have computer choose a target... should be Kafadar.
		BoardCell aiTwoSelectedTarget= aiTwo.selectTarget(targets);
		
		
		// ensure that ai2 selection is Kafadar
		assertTrue(aiTwoSelectedTarget.equals(board.getCell(3, 12)));
		
		
		//AI THREE
		
		// Could Enter Kafadar, Green Center or CoorsTek
		//because Kafadar is in seen list, and Green Center is in hand, should enter coorsTek
		// starting at (8,18) and rolling a 6
		
		board.calcTargets(board.getCell(8, 18), 6);
		targets= board.getTargets();
		
		int[] startLocThree= {8,18}; //Starting position for test
		Player aiThree = new ComputerPlayer("aiThree", "Yellow", startLocThree);
		
		// set Kafadar as a card that has been seen
		Set<Card> seenRooms = new HashSet<>();
		seenRooms.add(kafadarCard);
		
		aiThree.setSeenCards(seenRooms);
		aiThree.setSeenRoom(seenRooms);
		
		// set Green Center to be in hand
		Set<Card> inHandRooms = new HashSet<>();
		seenRooms.add(greenCard);
		
		aiThree.setPersonCards(inHandRooms);
		
		// have computer choose a target... should be CoorsTek.
		BoardCell aiThreeSelectedTarget= aiThree.selectTarget(targets);		
		assertTrue(aiThreeSelectedTarget.equals(board.getCell(12, 12)));
	}
}
