package tests;

/*
 * This program tests that config files are loaded properly.
 */

// Doing a static import allows me to write assertEquals rather than
// Assert.assertEquals
import static org.junit.Assert.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import clueGame.Board;
import clueGame.Card;
import clueGame.CardType;

public class CardTests{
	private static Board board;
	@BeforeAll
	public static void setUp() {
		board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
		board.initialize();
		
	}
	@Test
	public void cardPeopleTests() {
		Card pcj = new Card("President PCJ", CardType.PERSON);
		assertTrue(board.deckContainsCard(pcj));
	
		Card baldwin = new Card("Professor Baldwin", CardType.PERSON);
		assertTrue(board.deckContainsCard(baldwin));
		
		Card olson = new Card("Officer Olson", CardType.PERSON);
		assertTrue(board.deckContainsCard(olson));
		
		Card howard = new Card("Director Howard", CardType.PERSON);
		assertTrue(board.deckContainsCard(howard));

		Card sodexo = new Card("Chef Sodexo", CardType.PERSON);
		assertTrue(board.deckContainsCard(sodexo));

		Card scott = new Card("Compsci Scott", CardType.PERSON);
		assertTrue(board.deckContainsCard(scott));

	}
	@Test
	public void cardWeaponsTests() {
		Card hold = new Card("Registration Hold", CardType.WEAPON);
		assertTrue(board.deckContainsCard(hold));
		
		Card lecture = new Card("Stern Lecture", CardType.WEAPON);
		assertTrue(board.deckContainsCard(lecture));
		
		Card hitRun = new Card("Hit and Run", CardType.WEAPON);
		assertTrue(board.deckContainsCard(hitRun));
		
		Card charger = new Card("Computer Charger", CardType.WEAPON);
		assertTrue(board.deckContainsCard(charger));
		
		Card chicken = new Card("Under-cooked Chicken", CardType.WEAPON);
		assertTrue(board.deckContainsCard(chicken));
		
		Card violation = new Card("Coding Standards Violation", CardType.WEAPON);
		assertTrue(board.deckContainsCard(violation));
	}
	
	@Test
	public void cardRoomTests() {
		Card kafadar = new Card("Kafadar", CardType.ROOM);
		assertTrue(board.deckContainsCard(kafadar));
		
		Card guggenheim = new Card("Guggenheim", CardType.ROOM);
		assertTrue(board.deckContainsCard(guggenheim));
		
		Card green = new Card("Green Center", CardType.ROOM);
		assertTrue(board.deckContainsCard(green));
		
		Card berthod = new Card("Berthod Hall", CardType.ROOM);
		assertTrue(board.deckContainsCard(berthod));
		
		Card alderson = new Card("Alderson Hall", CardType.ROOM);
		assertTrue(board.deckContainsCard(alderson));
		
		Card marquez = new Card("Marquez Hall", CardType.ROOM);
		assertTrue(board.deckContainsCard(marquez));
		
		Card ctlm = new Card("CTLM", CardType.ROOM);
		assertTrue(board.deckContainsCard(ctlm));
		
		Card coorsTek = new Card("CoorsTek", CardType.ROOM);
		assertTrue(board.deckContainsCard(coorsTek));
		
		Card brown = new Card("Brown Building", CardType.ROOM);
		assertTrue(board.deckContainsCard(brown));

	}
	
	
	
	
	
}