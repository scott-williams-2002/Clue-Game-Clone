package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import experiment.TestBoard;
import experiment.TestBoardCell;
/**
 * 
 * @author Calla Winner and Scott Williams
 * Description:
 * This class uses Junit 5 and five test methods in order to create test cases for the clue board and cell classes. 
 * The tests mainly ensure the calc and get target methods of the board class function. Also, the methods test functionality
 * of cells designated as rooms and when they are occupied. 
 *
 */

class BoardTestsExp {
	TestBoard board;
	
	@BeforeEach // Run before each test
	public void setUp() {
		//board should create the adjacency list
		board = new TestBoard();
	}
	
	// For the test board, ensure that every cell has the correct adjacency lists
	@Test
	public void testAdjacency() {
		int boardSize = 4;
		
		// loop through each cell
		for (int r = 0; r < boardSize; r++) { 
			for (int c = 0; c < boardSize; c++) { 
				TestBoardCell cell = board.getCell(r, c);
				Set<TestBoardCell> testList = cell.getAdjMtx();
				
				// test contents of the adjacency list
				if (r != 0) {
					Assert.assertTrue(testList.contains(board.getCell(r - 1, c)));
				}
				if (c != 0) {
					Assert.assertTrue(testList.contains(board.getCell(r, c - 1)));
				}
				if (r != boardSize - 1) {
					Assert.assertTrue(testList.contains(board.getCell(r + 1, c )));
				}
				if (c != boardSize - 1) {
					Assert.assertTrue(testList.contains(board.getCell(r, c + 1 )));
				}
				
				
				// test size of the list below
				
				//test that the corners have 2 adjacent cells
				if ( (r == 0 && c == 0) || (r == boardSize - 1 && c == 0) || (r == 0 && c == boardSize - 1) || (r == boardSize - 1 && c == boardSize - 1) ) {
					Assert.assertEquals(2,  testList.size());
				}
				else if (r == 0) {
					Assert.assertEquals(3,  testList.size());
				}
				else if (c == 0) {
					Assert.assertEquals(3,  testList.size());
				}
				else if (r == boardSize - 1) {
					Assert.assertEquals(3,  testList.size());
				}
				else if (c == boardSize - 1) {
					Assert.assertEquals(3,  testList.size());
				}
				else {
					Assert.assertEquals(4,  testList.size());
				}
				
			} // end of col loop
		}// end of row loop
	} // end testAdjacency
	
	
	
	// test targets with several rolls and start locations
	@Test
	public void testTargetsNormal() {
		//test case 1
		// for position 0,0  with a roll of 3
		TestBoardCell cell = board.getCell(0, 0);
		board.calcTargets(cell, 3); // roll 3
		Set<TestBoardCell> targets = board.getTargets();

		Assert.assertEquals(6, targets.size());
		Assert.assertTrue(targets.contains(board.getCell(3, 0)));
		Assert.assertTrue(targets.contains(board.getCell(2, 1)));
		Assert.assertTrue(targets.contains(board.getCell(0, 1)));
		Assert.assertTrue(targets.contains(board.getCell(1, 2)));
		Assert.assertTrue(targets.contains(board.getCell(0, 3))); // failing this one
		Assert.assertTrue(targets.contains(board.getCell(1, 0)));
		
		//test case 2
		//for position 2,2 with a roll of 4
		cell = board.getCell(2, 2);
		board.calcTargets(cell, 4);
		targets = board.getTargets();
		Assert.assertEquals(7, targets.size());
		Assert.assertTrue(targets.contains(board.getCell(0,0)));
		Assert.assertTrue(targets.contains(board.getCell(0,2)));
		Assert.assertTrue(targets.contains(board.getCell(1,1)));
		Assert.assertTrue(targets.contains(board.getCell(1,3)));
		Assert.assertTrue(targets.contains(board.getCell(2,0)));
		Assert.assertTrue(targets.contains(board.getCell(3,1)));
		Assert.assertTrue(targets.contains(board.getCell(3,3)));
		
		
		//test case 4
		//for position 2,2 with a roll of 2
		cell = board.getCell(2, 2);
		board.calcTargets(cell, 2);
		targets = board.getTargets(); 
		Assert.assertEquals(6, targets.size());
		Assert.assertTrue(targets.contains(board.getCell(1,1)));
		Assert.assertTrue(targets.contains(board.getCell(1,3)));
		Assert.assertTrue(targets.contains(board.getCell(3,1)));
		Assert.assertTrue(targets.contains(board.getCell(3,3)));
		Assert.assertTrue(targets.contains(board.getCell(0,2)));
		Assert.assertTrue(targets.contains(board.getCell(2,0)));
		
		
		//test case 5
		//for position 1,1 with a roll of 5
		cell = board.getCell(1, 1);
		board.calcTargets(cell, 5);
		targets = board.getTargets(); 
		Assert.assertEquals(8, targets.size());
		Assert.assertTrue(targets.contains(board.getCell(0,1)));
		Assert.assertTrue(targets.contains(board.getCell(0,3)));
		Assert.assertTrue(targets.contains(board.getCell(1,0)));
		Assert.assertTrue(targets.contains(board.getCell(1,2)));
		Assert.assertTrue(targets.contains(board.getCell(2,1)));
		Assert.assertTrue(targets.contains(board.getCell(2,3)));
		Assert.assertTrue(targets.contains(board.getCell(3,0)));
		Assert.assertTrue(targets.contains(board.getCell(3,2)));
		
		//test case 6
		//for position 1,1 with a roll of 7
		cell = board.getCell(1, 1);
		board.calcTargets(cell, 6);
		targets = board.getTargets();
		Assert.assertEquals(7, targets.size());
		Assert.assertTrue(targets.contains(board.getCell(0,0)));
		Assert.assertTrue(targets.contains(board.getCell(0,2)));
		Assert.assertTrue(targets.contains(board.getCell(1,3)));
		Assert.assertTrue(targets.contains(board.getCell(2,0)));
		Assert.assertTrue(targets.contains(board.getCell(2,2)));
		Assert.assertTrue(targets.contains(board.getCell(3,1)));
		Assert.assertTrue(targets.contains(board.getCell(3,3)));
		
		//test case 7
		//for position 2,1 with a roll of 1
		cell = board.getCell(2, 1);
		board.calcTargets(cell, 1);
		targets = board.getTargets();
		Assert.assertEquals(4, targets.size());
		Assert.assertTrue(targets.contains(board.getCell(1,1)));
		Assert.assertTrue(targets.contains(board.getCell(2,0)));
		Assert.assertTrue(targets.contains(board.getCell(2,2)));
		Assert.assertTrue(targets.contains(board.getCell(3,1)));
		
		
		//test case 8
		//for position 0,0 with a roll of 4
		cell = board.getCell(0, 0);
		board.calcTargets(cell, 4);
		targets = board.getTargets();
		Assert.assertEquals(6, targets.size());
		Assert.assertTrue(targets.contains(board.getCell(0,2)));
		Assert.assertTrue(targets.contains(board.getCell(1,1)));
		Assert.assertTrue(targets.contains(board.getCell(1,3)));
		Assert.assertTrue(targets.contains(board.getCell(2,0)));
		Assert.assertTrue(targets.contains(board.getCell(2,2)));
		Assert.assertTrue(targets.contains(board.getCell(3,1)));
	}
	
	// tests interactions between calc target and rooms
	@Test
	public void testTargetsRoom() {
		// first case will make sure that a player can move into the cells of a room
		// 3 cells in the top left are room cells and the player rolls a 2. Starting from (1,1)
		TestBoardCell roomPart1 = board.getCell(0, 0);
		TestBoardCell roomPart2 = board.getCell(0, 1);
		TestBoardCell roomPart3 = board.getCell(0, 2);
		roomPart1.setRoom(true);
		roomPart2.setRoom(true);
		roomPart3.setRoom(true);
		
		// for roll of 2
		TestBoardCell playerCellCase1 = board.getCell(1, 1);
		board.calcTargets(playerCellCase1, 2);
		Set<TestBoardCell> targetsCase1 = board.getTargets();
		Assert.assertTrue(targetsCase1.contains(roomPart1)); // tests if the room cells are in the target list
		Assert.assertTrue(targetsCase1.contains(roomPart2));
		Assert.assertTrue(targetsCase1.contains(roomPart3));
		
		// same test but should not have room cells as an option because roll doesn't reach them 
		TestBoardCell playerCellCase2 = board.getCell(2, 2);
		board.calcTargets(playerCellCase2, 1);
		Set<TestBoardCell> targetsCase2 = board.getTargets();
		Assert.assertTrue(!targetsCase2.contains(roomPart1)); // tests if the room cells are not in the target list
		Assert.assertTrue(!targetsCase2.contains(roomPart2));
		Assert.assertTrue(!targetsCase2.contains(roomPart3));
	}
	
	// tests target cells when there are occupied cells 
	@Test
	public void testTargetsOccupied() {
		TestBoardCell occupiedPart1 = board.getCell(0, 0);
		TestBoardCell occupiedPart2 = board.getCell(0, 1);
		TestBoardCell occupiedPart3 = board.getCell(0, 2);
		occupiedPart1.setOccupied(true);
		occupiedPart2.setOccupied(true);     // sets the 3 spaces to be occupied 
		occupiedPart3.setOccupied(true);
		
		// for a roll of 2
		TestBoardCell playerCellCase1 = board.getCell(1, 1);
		board.calcTargets(playerCellCase1, 2);
		Set<TestBoardCell> targetsCase1 = board.getTargets();
		Assert.assertTrue(!targetsCase1.contains(occupiedPart1)); // tests to make sure occupied cells are not in target list as they shouldn't be a movement option
		Assert.assertTrue(!targetsCase1.contains(occupiedPart2));
		Assert.assertTrue(!targetsCase1.contains(occupiedPart3));
		Assert.assertTrue(targetsCase1.contains(board.getCell(1, 3)));
		Assert.assertTrue(targetsCase1.contains(board.getCell(2, 0)));
		Assert.assertTrue(targetsCase1.contains(board.getCell(2, 2)));
		Assert.assertTrue(targetsCase1.contains(board.getCell(3, 1)));
		Assert.assertEquals(4, targetsCase1.size()); // make sure not empty and has 3 targets
		
		
		
		// For a roll of 1 where they player has no possible moves due to occupied spaces
		TestBoardCell playerCellCase2 = board.getCell(0, 0);  // top left corner
		
		TestBoardCell occupiedSpaceLeft = board.getCell(1, 0);
		TestBoardCell occupiedSpaceRight = board.getCell(0, 1);
		occupiedSpaceLeft.setOccupied(true);
		occupiedSpaceRight.setOccupied(true);    // setting two free spaces to the left and right of start to occupied
		
		// roll of 1
		board.calcTargets(playerCellCase2, 1);
		Set<TestBoardCell> targetsCase2 = board.getTargets();
		
		// ensures that the player has no moves because surrounding cells are walls or occupied spaces
		Assert.assertTrue(targetsCase2.isEmpty());
	}
	
	//tests target cells when there are occupied cells and room cells
	@Test
	public void testMixedTargetConditions() {
		// First test simulates the point when a player can't enter a room because the door is blocked by an occupied cell
		//Room is in top left of board and occupied. Only one cell so should be treated as the door
		
		TestBoardCell occupiedRoom1 = board.getCell(0, 0);
		occupiedRoom1.setOccupied(true);
		occupiedRoom1.setRoom(true);
		
		// player starts this case close to the bottom right of the board and rolls a 6
		TestBoardCell PlayerCase1 = board.getCell(2, 2);
		board.calcTargets(PlayerCase1, 6);
		Set<TestBoardCell> targetsCase1 = board.getTargets();
		
		// passes if this occupied room isn't in the target set
		Assert.assertTrue(!targetsCase1.contains(occupiedRoom1));
		
		// Second case simulates a room made of 4 cells and one of the 4 cells is occupied. 
		// Test should pass if those 3 open room cells are in targets list and the occupied
		// cell isn't in the list
		
		TestBoardCell occupiedRoom2 = board.getCell(0, 0);
		TestBoardCell freeRoom1 = board.getCell(1, 0);
		freeRoom1.setRoom(true);
		TestBoardCell freeRoom2 = board.getCell(0, 1);
		freeRoom2.setRoom(true);
		TestBoardCell freeRoom3 = board.getCell(1, 1);
		freeRoom3.setRoom(true);
		
		//Player starts at (2,2) and has 5 moves, should be enough to move to all 3 open room cells
		TestBoardCell PlayerCase2 = board.getCell(2, 2);
		board.calcTargets(PlayerCase2, 5);
		Set<TestBoardCell> targetsCase2 = board.getTargets();
		
		Assert.assertTrue(!targetsCase2.contains(occupiedRoom2));     // shouldn't have occupied space
		Assert.assertTrue(targetsCase2.contains(freeRoom1));   // but should have the other 3 free room spaces
		Assert.assertTrue(targetsCase2.contains(freeRoom2));   
		Assert.assertTrue(targetsCase2.contains(freeRoom3)); 
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
