package tests;
/**
 * Authors: Calla Winner and Scott Williams
 * Description: Tests the functionality of the board, cells, rooms, and door directions using Junit.
 * Right now all tests fail as the classes mentioned have not been implemented properly yet. 
 */
import static org.junit.Assert.*;

import java.io.FileNotFoundException;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import clueGame.Board;
import clueGame.BoardCell;
import clueGame.DoorDirection;
import clueGame.Room;

import org.junit.jupiter.api.BeforeAll;

import clueGame.Board;

public class FileInitTest {
	
	// constants for testing file data loaded 
	public static final int LEGEND_SIZE = 11;
	public static final int NUM_ROWS = 29;
	public static final int NUM_COLUMNS = 29;
	public static final String LAYOUT_FILE_NAME = "ClueLayout.csv";
	public static final String SETUP_FILE_NAME = "ClueSetup.txt";
	private static Board board;
	
	// initializes the board and sets file names for all tests 
	@BeforeAll
	public static void setUp() {
		board = Board.getInstance();
		board.setConfigFiles(LAYOUT_FILE_NAME, SETUP_FILE_NAME);

		board.initialize();
	}
	
	// tests that the files are loaded correctly by ensuring first and last entries
	// of both are correct.
	@Test
	public void testFirstLastInFiles() {
		// testing top left and bottom right corners of csv/board file loaded properly
		// Uses char cell initial to test this. 
		assertEquals("X",board.getCell(0, 0).getInitial());
		assertEquals("X",board.getCell(28, 28).getInitial());
		
		// testing the first and last of the setup file are correct
		assertEquals("Kafadar", board.getRoom("K").getName());
		
		// last entry is Space, Walkway, W, so need to ensure that a walkway cell has the initial 'W'
		assertEquals("W", board.getCell(8, 0).getInitial()); //walkway at 8,0
	}
	
	// tests to see if the correct number of rows and columns for the board were read in
	@Test
	public void testNumRowsColumns() {
		// uses the static member variables above to check num rows/columns
		assertEquals(NUM_ROWS, board.getNumRows());
		assertEquals(NUM_COLUMNS, board.getNumColumns());	
	}
	
	// tests if cells are doors and their directions 
	// tests all directions and the NONE cases for door direction enum
	@Test
	public void testDoorways() {
		//testing 4 doorways with different directions
		assertTrue(board.getCell(7, 8).isDoorway()); // tests if is door 
		assertEquals(DoorDirection.UP, board.getCell(7, 8).getDoorDirection());  // for up door
		
		assertTrue(board.getCell(8, 9).isDoorway()); 
		assertEquals(DoorDirection.DOWN, board.getCell(8, 9).getDoorDirection());  // for down door
		
		assertTrue(board.getCell(3, 5).isDoorway()); 
		assertEquals(DoorDirection.LEFT, board.getCell(3, 5).getDoorDirection());  // for left door
		
		assertTrue(board.getCell(3, 7).isDoorway()); 
		assertEquals(DoorDirection.RIGHT, board.getCell(3, 7).getDoorDirection());  // for right door
		
		
		//Testing 3 different cells that are not doors and their direction (NONE)
		assertFalse(board.getCell(2, 1).isDoorway()); 
		assertEquals(DoorDirection.NONE, board.getCell(2, 1).getDoorDirection());  
		
		assertFalse(board.getCell(10, 3).isDoorway()); 
		assertEquals(DoorDirection.NONE, board.getCell(10, 3).getDoorDirection());
		
		assertFalse(board.getCell(26, 19).isDoorway()); 
		assertEquals(DoorDirection.NONE, board.getCell(26, 19).getDoorDirection());
	}
	
	// test that there are a total of 24 doors
		@Test
		public void testNumDoor() {
			BoardCell cell = board.getCell( 0, 0);
			int numDoors = 0;
			
			for (int r = 0; r < board.getNumRows(); r++) {
				for (int c = 0; c < board.getNumColumns(); c++) {
					cell = board.getCell(r, c);
					if (cell.isDoorway()) {
						numDoors++;
					} 
				} // end col loop
			}//end row loop
			
			assertEquals( numDoors, 24 ); // there are currently 24 doors in our set up	
		}
		
		// tests each room to see if the initials are set correctly
		@Test
		public void testInitials() {
			BoardCell cell = board.getCell( 0, 0);
			// test Guggenheim
			cell = board.getCell( 0, 3);
			assertTrue("GU".equals(cell.getInitial()));
			
			//test Kafadar
			cell = board.getCell( 1, 12);
			assertTrue("K".equals(cell.getInitial()));
			
			//test Green Center
			cell = board.getCell( 5, 22);
			assertTrue("GR".equals(cell.getInitial()));
			
			// test Berthod
			cell = board.getCell( 12, 1);
			assertTrue("BT".equals(cell.getInitial()));
			
			// test CoorsTek
			cell = board.getCell( 10, 9);
			assertTrue("C".equals(cell.getInitial()));
			
			//test Marquez
			cell = board.getCell( 20, 25);
			assertTrue("M".equals(cell.getInitial()));
			
			
			//test Brown
			cell = board.getCell( 24, 1);
			assertTrue("BR".equals(cell.getInitial()));
			
			//test Alderson
			cell = board.getCell( 22, 11);
			assertTrue("A".equals(cell.getInitial()));
			
			//test CTLM
			cell = board.getCell( 26, 22);
			assertTrue("CT".equals(cell.getInitial()));
			
			//test walkway
			cell = board.getCell( 10, 17);
			assertTrue("W".equals(cell.getInitial()));
			
			//test non-playable space
			cell = board.getCell( 26, 15);
			assertTrue("X".equals(cell.getInitial()));	
		}
		
		// tests proper center cell and label cell
		@Test
		public void testRoomCenterAndLabel() {
			BoardCell cellLabel = new BoardCell(0,0);
			BoardCell cellCenter = new BoardCell(0,0);
			Room room = board.getRoom(cellLabel);
			
			// test Guggenheim
			cellLabel = board.getCell(7, 1); //label
			cellCenter = board.getCell(3, 2); //Center
			room = board.getRoom( cellLabel );
			assertEquals(room.getLabelCell(), cellLabel);
			assertEquals("Guggenheim", room.getName());
			assertEquals(room.getCenterCell(), cellCenter);
			
			// test Kafadar
			cellLabel = board.getCell(6, 10); //label
			cellCenter = board.getCell(3, 12); //Center
			room = board.getRoom( cellLabel );
			assertEquals(room.getLabelCell(), cellLabel);
			assertEquals("Kafadar", room.getName());
			assertEquals(room.getCenterCell(), cellCenter);
			
			// test Green Center
			cellLabel = board.getCell(14, 21); //label
			cellCenter = board.getCell(8, 23); //Center
			room = board.getRoom( cellLabel );
			assertEquals(room.getLabelCell(), cellLabel);
			assertEquals("Green Center", room.getName());
			assertEquals(room.getCenterCell(), cellCenter);
			
			// test Berthod
			cellLabel = board.getCell(13, 1); //label
			cellCenter = board.getCell(12, 2); //Center
			room = board.getRoom( cellLabel );
			assertEquals(room.getLabelCell(), cellLabel);
			assertEquals("Berthod Hall", room.getName());
			assertEquals(room.getCenterCell(), cellCenter);
			
			// test CoorsTek
			cellLabel = board.getCell(14, 10); //label
			cellCenter = board.getCell(12, 12); //Center
			room = board.getRoom( cellLabel );
			assertEquals(room.getLabelCell(), cellLabel);
			assertEquals("CoorsTek", room.getName());
			assertEquals(room.getCenterCell(), cellCenter);
		}

}
