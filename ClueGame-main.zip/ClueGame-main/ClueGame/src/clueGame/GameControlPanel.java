package clueGame;
/*
 * Authors: Calla Winner and Scott Williams
 * GameControlPanel is used to handle input from the player and create trigger events
 * such as next button is pressed. It also displays the current player and roll number. 
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;


public class GameControlPanel extends JPanel{
	private int rollNumber;
	private String guess;
	private String guessResult;
	private String player;
	private Color playerColor;
	
	// modifiable text boxes
	private JTextField turnText;
	private JTextField rollText;
	private JTextField leftText;
	private JTextField rightText;
	private ActionListener buttonAction;
	private JButton nextButton;
	
	public GameControlPanel() {
		//initializes private vars to zero or empty
		rollNumber = 0;
		guess = "";
		guessResult = "";
		player = "";
		playerColor = Color.WHITE; //defaults player color box to white
		
		// set length of modifiable text boxes
		turnText = new JTextField(10);
		rollText = new JTextField(10);
		leftText = new JTextField(30);
		rightText = new JTextField(30);
		nextButton = new JButton("Next");
		
		// adds 2 rows to layout
		int controlPanelRows = 2;
		int controlPanelCols = 0;
		setLayout(new GridLayout(controlPanelRows, controlPanelCols));
		
		//creates new top and bottom sub-panels of controlPanel
		JPanel panelOne = new JPanel(); // entire top half
		JPanel panelTwo = new JPanel(); // entire bottom half
		
		// adds sub panels to top and bottom sub panels
		handleTopPanel(panelOne);
		handleBottomPanel(panelTwo);
		
		//adds sub-panels to game control panel
		add(panelOne);
		add(panelTwo);	
		
		//setting action listener for next button
		//buttonAction = buttonActionListener;
	}

	
	public void handleTopPanel(JPanel outerPanel) {
		
		//sets outer panel dimensions
		outerPanel.setLayout(new GridLayout(1,4));
		// panels left to right 1 and 2 in top sub-panel of gameControlPanel
		JPanel panelOne = new JPanel();
		JPanel panelTwo = new JPanel();
		
		//where turnText field is edited
		// for panelOne
		//adding text and fields on different lines which occurs because of 10 in text field
		JLabel turnLabel = new JLabel("Whose turn?");
		
		//setting turn text and color
		turnText.setBackground(playerColor);
		turnText.setText(player);
		//adding to panel
		panelOne.add(turnLabel);
		panelOne.add(turnText);
		outerPanel.add(panelOne); //adding to main panel outerPanel
		
		// for panelTwo
		// similar to panel one but adding the text and field on same line
		JLabel rollLabel = new JLabel("Roll:");
		
		//set roll text
		rollText.setText(String.valueOf(rollNumber));
		//changes rollText background color to same as panel
		rollText.setBackground(panelTwo.getBackground());
		panelTwo.add(rollLabel);
		panelTwo.add(rollText);
		outerPanel.add(panelTwo); //adding to outer panel
		
		//for left button 
		//adding button for make accusation next to panel 2
		JButton accuseButton = new JButton("Make Accusation");
		accuseButton.setBorder(new TitledBorder(new EtchedBorder()));
		outerPanel.add(accuseButton);
		
		//for right button 		
		// same as left button logic
		nextButton.setBorder(new TitledBorder(new EtchedBorder()));
		
		//setting action listener and command for both buttons
		nextButton.addActionListener(new GameActionListener());
		nextButton.setActionCommand("N");  //for identifying button pressed
		accuseButton.addActionListener(new GameActionListener());
		accuseButton.setActionCommand("A");  //for identifying button pressed
		
		outerPanel.add(nextButton);
	}
	

	//edits text and color for left panel
	public void setGuess(String guess, Color newColor) {
		leftText.setText(guess);
		leftText.setBackground(newColor);
	}

	//edits text and color for right panel
	public void setGuessResult(String guessResult, Color newColor) {
		rightText.setText(guessResult);
		rightText.setBackground(newColor);
	}

	//edits text and color for roll panel and player name panel
	public void setTurn(String playerName, int roll, Color newColor) {
		rollText.setText(String.valueOf(roll));
		turnText.setEditable(isBackgroundSet());
		turnText.setText(playerName.trim());
		turnText.setBackground(newColor);
		
	}

	// creates the subpanels and components on the bottom half of the controlPanel
	public void handleBottomPanel(JPanel outerPanel) {
		
		outerPanel.setLayout(new FlowLayout());
		//2 side by side panels with text fields and panel names
		JPanel panelLeft = new JPanel();
		JPanel panelRight = new JPanel();
		panelLeft.setBorder(BorderFactory.createTitledBorder("Guess"));
		panelRight.setBorder(BorderFactory.createTitledBorder("Guess Result"));

		//setting text to corresponding fields
		leftText.setText(guess);
		rightText.setText(guessResult);
		//sets the background color of text field to same as panel
		leftText.setBackground(panelLeft.getBackground());
		rightText.setBackground(panelRight.getBackground());
		panelLeft.add(leftText);
		panelRight.add(rightText);
		
		//adds 2 sub-panels to outer panel
		outerPanel.add(panelLeft);
		outerPanel.add(panelRight);
		
		
	}
	


}
