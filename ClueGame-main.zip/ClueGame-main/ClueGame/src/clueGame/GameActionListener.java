package clueGame;
/*
 * Authors: Calla Winner and Scott Williams
 * GameActionListener Class:
 * This class is responsible for handling the event that occurs when the next button is pressed. 
 */

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class GameActionListener implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e){

		//checking which button pressed
		if(e.getActionCommand().equals("N".trim()))//N is the action command for next button 
		{
			Board.getInstance().nextButtonPressed();
		}
		if(e.getActionCommand().equals("A".trim()))//A is the action command for make accusation button 
		{
			Board.getInstance().accusationIsPressed();

		}



	}
}
