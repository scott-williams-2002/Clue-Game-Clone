package clueGame;

public enum CardType { 
	ROOM, PERSON, WEAPON
}
