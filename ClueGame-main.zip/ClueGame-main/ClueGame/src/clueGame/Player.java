package clueGame;
/*
 * Authors: Calla Winner and Scott Williams
 * Player is an abstract class, which has children that are human and computer. Used for storing info for each player and 
 * for moving and displaying the players. 
 */
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public abstract class Player {
	private int[] moveToLocation;
	private String playerName;
	private String color;
	private int row, col;
	private Color colorObj;
	public Color getColorObj() {
		return colorObj;
	}


	public void setColorObj(Color colorObj) {
		this.colorObj = colorObj;
	}


	public void setStartLocation(int[] startLocation) {
		this.startLocation = startLocation;
	}

	private int[] startLocation;
	private Set<Card> playerCards = new HashSet<>();
	private Set<Card> seenCards = new HashSet<>();
	private Set<Card> seenWeapons = new HashSet<>();
	private Set<Card> seenPeople = new HashSet<>();
	private Set<Card> seenRoom = new HashSet<>();
	private static Set<Card> allPossibleWeapons = new HashSet<>();
	private static Set<Card> allPossiblePeople = new HashSet<>();
	private static Set<Card> allPossibleRooms = new HashSet<>();
	private int boardRows;
	private int boardCols;
	private boolean isDoneWithTurn;
	private boolean isDoneWithTargetSelection;
	private boolean isCurrentlyMakingSuggestion;
	private int roll;
	private int shiftValue;

	public Player(String playerName, String color, int[] startLocation) {
		super();
		this.playerName = playerName;
		allPossibleWeapons = new HashSet<Card>();
		allPossiblePeople = new HashSet<Card>();
		allPossibleRooms = new HashSet<Card>();

		this.color = color;
		this.startLocation = startLocation;
		colorObj = new Color(0,0,0);
		this.getColorObject();
		setDoneWithTurn(true);
		setDoneWithTargetSelection(false);
		setCurrentlyMakingSuggestion(false);
		shiftValue = 0;
	}


	public int getShiftValue() {
		return shiftValue;
	}


	public void setShiftValue(int shiftValue) {
		this.shiftValue = shiftValue;
	}


	private void getColorObject() {
		if(color.trim().equals("Purple")) {
			colorObj = Color.PINK;
		}
		if(color.trim().equals("Yellow")) {
			colorObj = Color.YELLOW;
		}
		if(color.trim().equals("Blue")) {
			colorObj = Color.BLUE;
		}
		if(color.trim().equals("Red")) {
			colorObj = Color.RED;
		}
		if(color.trim().equals("Brown")) {
			colorObj = Color.CYAN;
		}
		if(color.trim().equals("Green")) {
			colorObj = Color.GREEN;
		}

	}
	public String getPlayerName() {
		return playerName;
	}

	public Color getColor() {
		return colorObj;
	}


	public int[] getStartLocation() {
		return startLocation;
	}

	public void updateHand(Card card) {
		this.playerCards.add(card);
	}
	public Set<Card> getPlayerCards(){
		return playerCards;
	}

	public void updateSeen(Card seenCard) {
		seenCards.add(seenCard);

		// add to sub-sets
		switch (seenCard.getCardType()) {
		case WEAPON:
			seenWeapons.add(seenCard);
			break;
		case PERSON:
			seenPeople.add(seenCard);
			break;
		
		case ROOM:
			seenRoom.add(seenCard);
			break;
		}
	}

	// returns card or null given the card the disproves the suggestion
	public Card disproveSuggestion(Card[] suggestion) {

		// cards in common with suggestion
		ArrayList<Card> commonCards = new ArrayList<>();
		for(Card suggestedCard : suggestion) {
			for(Card playerCard : playerCards) {
				if(playerCard.equals(suggestedCard)) {
					commonCards.add(suggestedCard);
				}
			}
		}
		if (commonCards.isEmpty()) {
			return null;
		}
		else if (commonCards.size() == 1) {
			return commonCards.get(0);
		}
		// picks a random int between 0 and the highest index in common cards arraylist
		// and uses it to choose a random card by indexing the arraylist
		else {
			Random rng = new Random();
			int max = commonCards.size() - 1;
			int min = 0; 
			int randomNum = Math.abs(rng.nextInt()%(max - min + 1));
			return commonCards.get(randomNum);
		}
	}


	public abstract Card[] createSuggestion(String roomName);

	public void setWeaponCards(Set<Card> weapons) {
		this.allPossibleWeapons = weapons;
	}


	public static Set<Card> getAllPossibleWeapons() {
		return allPossibleWeapons;
	}



	public static Set<Card> getAllPossiblePeople() {
		return allPossiblePeople;
	}


	public static void setPersonCards(Set<Card> allPossiblePeople) {
		Player.allPossiblePeople = allPossiblePeople;
	}


	public Set<Card> getSeenWeapons() {
		return seenWeapons;
	}


	public void setSeenWeapons(Set<Card> seenWeapons) {
		this.seenWeapons = seenWeapons;
	}


	public Set<Card> getSeenPeople() {
		return seenPeople;
	}


	public void setSeenPeople(Set<Card> seenPeople) {
		this.seenPeople = seenPeople;
	}


	public void setSeenCards(Set<Card> seenCards) {
		this.seenCards = seenCards;
	}


	public static Set<Card> getAllPossibleRooms() {
		return allPossibleRooms;
	}


	public static void initializeAllPossibleSets() {
		Set<Card> deck = Board.getInstance().getDeck();
		for (Card card : deck) {
			if (card.getCardType() == CardType.ROOM) {
				allPossibleRooms.add(card);
			}
			if (card.getCardType() == CardType.PERSON) {
				allPossiblePeople.add(card);
			}
			if (card.getCardType() == CardType.WEAPON) {
				allPossibleWeapons.add(card);
			}
		}
	}


	public static void setAllPossibleWeapons(Set<Card> allPossibleWeapons) {
		Player.allPossibleWeapons = allPossibleWeapons;
	}


	public static void setAllPossiblePeople(Set<Card> allPossiblePeople) {
		Player.allPossiblePeople = allPossiblePeople;
	}


	public static void setAllPossibleRooms(Set<Card> allPossibleRooms) {
		Player.allPossibleRooms = allPossibleRooms;
	}


	public int getRow() {
		return row;
	}


	public int getCol() {
		return col;
	}

	public Set<Card> getSeenCards() {
		return seenCards;
	}

	public int getNumberOfInHand(CardType type) {
		int numInHand = 0;

		switch (type) {
		case WEAPON:
			for (Card card : this.getPlayerCards()) {
				if (card.getCardType().equals(CardType.WEAPON)) {
					numInHand++;
				}
			}

			break;
		case PERSON:
			for (Card card : this.getPlayerCards()) {
				if (card.getCardType().equals(CardType.PERSON)) {
					numInHand++;
				}
			}

			break;
		case ROOM:
			for (Card card : this.getPlayerCards()) {
				if (card.getCardType().equals(CardType.ROOM)) {
					numInHand++;
				}
			}

			break;


		}

		return numInHand;
	}

	public abstract BoardCell selectTarget(Set<BoardCell> targets);

	public abstract Boolean isHumanPlayer();


	public Set<Card> getSeenRoom() {
		return seenRoom;
	}


	public void setSeenRoom(Set<Card> seenRoom) {
		this.seenRoom = seenRoom;
	}

	//sets number of rows and columns in grid 
	public void setNumRowsCols(int numRows, int numCols) {
		boardRows = numRows;
		boardCols = numCols;
	}


	public void drawPlayers(Graphics g, int panelWidth, int panelHeight, int shiftValue) {
		//need to set color before editing graphic
		double width = (panelWidth / boardRows);
		double height = (panelHeight / boardCols);
		int xLocation, yLocation;

		//int borderBuffer = 5;  //width of border around cells that will have border
		yLocation = (int) (height * startLocation[0]);
		xLocation = (int) (width * startLocation[1]) + shiftValue;

		g.setColor(colorObj);
		g.fillOval(xLocation, yLocation, (int)width, (int)height);
	}

	public int rollDice() {
		Random rand = new Random();
		roll = rand.nextInt(6) +  1;
		return roll;
	}

	public int getRoll() {
		return roll;
	}
	public void movePlayerToNewLoc(BoardCell newLocation) {
		startLocation = newLocation.getLocation();
		Board.getInstance().repaint();
		Board.getInstance().revalidate();
		// update location variable after you move
	}


	public boolean isDoneWithTurn() {
		return isDoneWithTurn;
	}


	public void setDoneWithTurn(boolean isDoneWithTurn) {
		this.isDoneWithTurn = isDoneWithTurn;
	}


	public boolean isDoneWithTargetSelection() {
		return isDoneWithTargetSelection;
	}


	public void setDoneWithTargetSelection(boolean isDoneWithTargetSelection) {
		this.isDoneWithTargetSelection = isDoneWithTargetSelection;
	}


	public boolean isCurrentlyMakingSuggestion() {
		return isCurrentlyMakingSuggestion;
	}


	public void setCurrentlyMakingSuggestion(boolean isCurrentlyMakingSuggestion) {
		this.isCurrentlyMakingSuggestion = isCurrentlyMakingSuggestion;
	}

	public void addToSeenDeck(Card card) {
		seenCards.add(card);
	}

	
	// Moves parameter player to the instance player
	public void moveToLocation(Player playerToBeMoved) {
		playerToBeMoved.setStartLocation(this.getStartLocation());
		int shift;
		if (!playerToBeMoved.equals(this)) {
			Random rand = new Random();
			shift = rand.nextInt(10) + 10;
		}
		else {
			shift = 0; 
		}
		playerToBeMoved.setShiftValue(shift);
		Board.getInstance().repaint();
		Board.getInstance().revalidate();
	}



}
