package clueGame;
import java.io.PrintWriter;
import java.io.IOException;
/**
 * 
 * @author Calla Winner & Scott Williams
 * Description:
 * This class is a user defined exception that is thrown 
 * when there is an issue with the configuration format
 * of the board. The error message is printed in a file called logFile.txt 
 * which is located in the clueGame directory. 
 */
public class BadConfigFormatException extends Exception{

	public BadConfigFormatException() {
		super("Your Configuration Files are Incorrect.");
		
		// try catch for writing to logfile 
		try {
			PrintWriter logFile = new PrintWriter("logFile.txt", "UTF-8");
			logFile.println("Your Configuration Files are Incorrect.");
			logFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public BadConfigFormatException(String msg) {
		// calls parent with the message (msg) as an input
		super(msg);
		try {
			PrintWriter logFile = new PrintWriter("logFile.txt", "UTF-8");
			logFile.println(msg);
			logFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
