package clueGame;
/**
 * Authors: Calla Winner and Scott Williams
 * Description:
 * Represents the board of cells and rooms. Uses the Singleton pattern to ensure only one
 * instance of the board exists. Running from Board class will essentially run the whole game, because
 * the game is opperated from board's main. 
 * 
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Arrays;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.*;

public class Board extends JPanel implements MouseListener{
	private BoardCell[][] grid;
	private int numRows;
	private int numCols;
	private String layoutConfigFile;
	private String setupConfigFile;
	private Map<String, Room> roomMap; // initial to 
	private ArrayList<String> roomNames;
	private Card[] solution;
	private Set<BoardCell> targets;
	private Set<BoardCell> visited;
	private Set<Player> playersSet;
	private Set<Card> deck;
	private Queue<Player> playerQueue;
	private static Board theInstance;
	private Boolean isHumansTurn;
	private Boolean nextWasPressed;
	private Player currentPlayer;
	private ClueGame window;

	// The Singleton type class "Constructor":
	private Board() {
		super();
	}
	
	
	//Initializes all the private variables in board class using file reader
	public void initialize() {
		try {
			deck = new HashSet<>();
			targets = new HashSet<>();
			visited = new HashSet<>();
			playersSet = new HashSet<>();
			solution = new Card[3];
			playerQueue = new LinkedList<>();
			nextWasPressed = false;
			loadSetupConfig();
			loadLayoutConfig();
			createSolution();
			loadPlayerCards();

		}

		catch (FileNotFoundException | BadConfigFormatException e) {
			e.printStackTrace();
		}
	}

	// returns the single instance of the board
	public static Board getInstance() {
		if(theInstance == null) {
			theInstance = new Board();	
		}
		return theInstance;
	}

	// Loads the Setup Configuration File
	public void loadSetupConfig() throws BadConfigFormatException{
		String delimiter = ",";
		String thisLine;		  				

		// these are the sections of the txt file with corresponding data. They will be used to index that
		// data from the array in the while loop below
		int identifierIndex = 0;
		int nameIndex = 1;
		int characterIndex = 2;
		int colorIndex = 3;
		int rowStartIndex = 4;
		int colStartIndex = 5;

		//initializing the roomMap

		roomMap = new HashMap<>(); 
		roomNames = new ArrayList<>();

		try {
			BufferedReader setupFileReader = new BufferedReader(new FileReader(setupConfigFile));

			// first while loop to get num rows and num cols
			while ((thisLine = setupFileReader.readLine()) != null)  {  
				String[] row = thisLine.split(delimiter);   // splits the string of each line in .txt file into an array

				if(row[identifierIndex].equals("Room")) {
					Room tempRoom = new Room(row[nameIndex].trim());
					String initials = row[characterIndex].trim();
					roomMap.put(initials, tempRoom); // maps initials to the room ie GR -> Green Center
					roomNames.add(initials);
					Card card = new Card(row[nameIndex].trim(), CardType.ROOM);
					//setting color of room card to same custom color of rooms
					card.setCardColor(new Color(153,205,255));
					deck.add(card);

				}
				if(row[identifierIndex].equals("Space")) { // makes spaces a room class as well
					Room tempRoom = new Room(row[nameIndex].trim());
					String initials = row[characterIndex].trim();
					roomMap.put(initials, tempRoom); 
				}
				if(row[identifierIndex].equals("Card")) { // makes cards
					String cardName = row[nameIndex].trim();
					String type = row[characterIndex].trim();

					// make the cards and add them to deck
					switch (type) {
					case "Person":
						//make card
						Card cardp = new Card(cardName, CardType.PERSON);
						//setting person card to green
						cardp.setCardColor(Color.GREEN);
						deck.add(cardp);

						//make players
						int[] startLocation = {Integer.parseInt(row[rowStartIndex].trim()), Integer.parseInt(row[colStartIndex].trim())};

						// make one human and rest computer player
						if (cardName.equals("Compsci Scott")) {
							Player player = new HumanPlayer(cardName, row[colorIndex], startLocation);
							playersSet.add(player);
						}
						else {
							Player player = new ComputerPlayer(cardName, row[colorIndex], startLocation);
							playersSet.add(player);
						}

						break;
					case "Weapon":
						Card cardw = new Card(cardName, CardType.WEAPON);
						//setting weapon card color to red
						cardw.setCardColor(Color.RED);
						deck.add(cardw);
						break;
					default:
						throw new BadConfigFormatException("Error With Card Type.");
					}

				}

			}

			setupFileReader.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}


	// This method reads the data from the layout csv 2 times
	// The first time gets the dimensions and the second time gets the information 
	// for each cell and loads boardcells into the grid 2d array 
	public void loadLayoutConfig() throws  FileNotFoundException, BadConfigFormatException{
		//layoutConfigFile = "data/" + layoutConfigFile;   //path to file
		String delimiter = ",";                          //what seperates the values in csv
		int rowCounter = 0;                              
		int columnCounter = 0;
		String thisLine;
		ArrayList<String[]> layoutDataHolder = new ArrayList<>(); // holds data after reading and used to get 
		// the dimensions of the grid


		try {
			BufferedReader layoutFileReader = new BufferedReader(new FileReader(layoutConfigFile));

			// first while loop to get num rows and num cols
			while ((thisLine = layoutFileReader.readLine()) != null)  {  

				String[] row = thisLine.split(delimiter);   // splits the string of each line in csv into an array
				layoutDataHolder.add(row); // adds data to arraylist
				columnCounter = row.length; // gets number of columns by length of a row
				rowCounter ++;
			}

			// since the size of the board is known, we can initialize the space in our grid 2d array
			this.grid = new BoardCell[rowCounter][columnCounter];
			layoutFileReader.close();
			int rowIterator = 0;     //needed because no iterator on while/for each loops

			// second loop for getting actual data
			for (String[] row : layoutDataHolder)  {  

				// same as above loop, splits into an array

				int colIterator = 0;
				for(String cellData : row) {
					// exception for incorrect row number 
					if(row.length != columnCounter) {
						throw new BadConfigFormatException("There are missing cells in your csv file.");
					}

					BoardCell tempCell = new BoardCell(rowIterator, colIterator);   // loads new boardcells into grid

					tempCell.setInitial(cellData.trim());


					if (tempCell.isLabel()) { // if is a label Cell
						roomMap.get(tempCell.getInitial()).setLabelCell(tempCell); // set the room's label cell
						tempCell.setRoom(roomMap.get(tempCell.getInitial()));
					}
					if (tempCell.isRoomCenter()) { // if is a center cell
						roomMap.get(tempCell.getInitial()).setCenterCell(tempCell); // set the room's center cell
						tempCell.setRoom(roomMap.get(tempCell.getInitial()));
					}

					if (roomMap.get(tempCell.getInitial()) == null){ // if map is null, is secret passage
						tempCell.setSecretPassage(true);
					}
					tempCell.setIsRoom();

					//checking if the name of the cells is correct in layout and setup files
					if(!roomMap.containsKey(tempCell.getInitial())) {
						throw new BadConfigFormatException("Your room names and cell initials are not consistent");
					}

					grid[rowIterator][colIterator] = tempCell;
					colIterator ++;
				}

				rowIterator ++;	

			} // end of while loop

		} 

		catch (IOException e) {
			e.printStackTrace();
		}

		// sets row/column values correctly
		numRows = rowCounter;
		numCols = columnCounter;

		// for every cell in grid, set the adj matrix
		for (int r = 0; r < numRows; r++) {
			for (int c = 0; c < numCols; c++) {
				// if is walkway and is not a door
				if (grid[r][c].isWalkway() && grid[r][c].getDoorDirection() == DoorDirection.NONE  ) { 
					grid[r][c].setAdjMtx(calcAdjInBoardForWalkway(r,c));
				}
				// if it is a doorway
				if(grid[r][c].isWalkway() && grid[r][c].getDoorDirection() != DoorDirection.NONE) {
					grid[r][c].setAdjMtx(calcAdjInBoardForDoorway(r,c));
				}
				// if it is secret passage
				if (grid[r][c].getSecretPassage() != null) {
					calcAdjInBoardForPassage(r,c);
				}

				grid[r][c].setNumRowsCols(numRows, numCols);// sets the numbers of rows and columns in board for each cell

			}
		}

	}
	public Set<BoardCell> calcAdjInBoardForWalkway(int r, int c) {
		Set<BoardCell> adjMtx = new HashSet<>(); // Contains all cells adjacent to this cell
		if (r != 0 && getCell(r - 1, c).isWalkway()) {
			adjMtx.add(getCell(r - 1, c));
		}
		if (c != 0 && getCell(r, c - 1).isWalkway()) {
			adjMtx.add(getCell(r, c - 1));
		}
		if (r != numRows - 1 && getCell(r + 1, c).isWalkway()) {
			adjMtx.add(getCell(r + 1, c ));
		}
		if (c != numCols - 1 && getCell(r, c + 1).isWalkway()) {
			adjMtx.add(getCell(r, c + 1 ));
		}
		return adjMtx;
	}



	// handles doorways for calculating adj mtx
	public Set<BoardCell> calcAdjInBoardForDoorway(int r, int c){
		Set<BoardCell> adjMtx = new HashSet<>(); // Contains all cells adjacent to this cell

		// first see where doorway is pointing to
		if (getCell(r, c).getDoorDirection() == DoorDirection.UP ) {
			Room room = roomMap.get(getCell(r - 1, c).getInitial());
			adjMtx.add(room.getCenterCell());// adding to doorway adj mtx
			room.getCenterCell().addToAdjMtx(getCell(r, c)); // adding to center cell adj mtx
		}
		if (getCell(r, c).getDoorDirection() == DoorDirection.DOWN ) {
			Room room = roomMap.get(getCell(r + 1, c).getInitial());
			adjMtx.add(room.getCenterCell());// adding to doorway adj mtx
			room.getCenterCell().addToAdjMtx(getCell(r, c)); // adding to center cell adj mtx
		}
		if (getCell(r, c).getDoorDirection() == DoorDirection.RIGHT ) {
			Room room = roomMap.get(getCell(r, c + 1).getInitial());
			adjMtx.add(room.getCenterCell());// adding to doorway adj mtx
			room.getCenterCell().addToAdjMtx(getCell(r, c)); // adding to center cell adj mtx
		}
		if (getCell(r, c).getDoorDirection() == DoorDirection.LEFT ) {
			Room room = roomMap.get(getCell(r, c - 1).getInitial());
			adjMtx.add(room.getCenterCell());// adding to doorway adj mtx
			room.getCenterCell().addToAdjMtx(getCell(r, c)); // adding to center cell adj mtx
		}

		Set<BoardCell> restOfWalkways = calcAdjInBoardForWalkway(r,c);
		adjMtx.addAll(restOfWalkways);
		return adjMtx;
	}

	public void calcAdjInBoardForPassage(int r, int c){
		Room passageRoom = roomMap.get(getCell(r, c).getSecretPassage());
		Room currentRoom = roomMap.get(getCell(r, c).getInitial());

		passageRoom.getCenterCell().addToAdjMtx(currentRoom.getCenterCell()); // add current room to passage room adj mtx
		currentRoom.getCenterCell().addToAdjMtx(passageRoom.getCenterCell()); // add passage room to current room adj mtx
	}

	// Calculates the legal targets for a move from startCell of length pathLength
	public void calcTargets(BoardCell startCell, int pathlength){
		visited.clear();
		targets.clear();
		visited.add(startCell);
		initializeOccupied();
		findAllTargets(startCell, pathlength);
		repaint();
		revalidate();
	}

	// recursive function for calcTargets
	public void findAllTargets(BoardCell thisCell, int numSteps) {
		for (BoardCell adjCell : thisCell.getAdjListFromCell()) {
			// if already in visited list, skip rest of this 
			if (visited.contains(adjCell)|| (adjCell.isOccupied())){ //&& (adjCell.isARoom() == false))) { // make sure if its occupied its not a room
				continue; //skip
			} 

			//add adjCell to visited list
			visited.add(adjCell);

			// If there is only on step left or player is able to enter room, add to targets list
			if(numSteps == 1 || (adjCell.isARoom() && !adjCell.isOccupied())) {
				targets.add(adjCell);
			}
			else {// else call findAllTargets() with adjCell, numSteps-1 
				findAllTargets(adjCell, numSteps - 1);
			}

			visited.remove(adjCell); //remove adjCell from visited list
		}
	}

	public void createSolution() {
		int personIndex = 0;
		int weaponIndex = 1;
		int locIndex = 2;
		Card[] deckArray = new Card[deck.size()];

		int iterator = 0;
		for (Card card : deck) {
			deckArray[iterator] = card;
			iterator++;
		}

		Random rnd = new Random();

		// Find a solution with 1 card of each type (PERSON, WEAPON, ROOM)
		while(solution[personIndex] == null || solution[weaponIndex] == null || solution[locIndex]  == null) {

			int randIndex = rnd.nextInt(deckArray.length); // finds random index in range 0 to number of cards in deck
			if (deckArray[randIndex].getCardType().equals(CardType.PERSON) && solution[personIndex] == null) {
				solution[personIndex] = deckArray[randIndex];
			}
			if (deckArray[randIndex].getCardType().equals(CardType.WEAPON) && solution[weaponIndex] == null) {
				solution[weaponIndex] = deckArray[randIndex];
			}
			if (deckArray[randIndex].getCardType().equals(CardType.ROOM) && solution[locIndex] == null) {
				solution[locIndex] = deckArray[randIndex];
			}
		} 	
		
		
	}


	public void loadPlayerCards() {
		Card solutionPerson = solution[0];
		Card solutionWeapon = solution[1];
		Card solutionLocation = solution[2];
		Queue<Card> deckToDeal = new LinkedList<>();

		// builds the Deck (not including solution cards)
		int numCards = 0;
		for (Card tempCard: deck) {
			if (!tempCard.equals(solutionPerson) && !tempCard.equals(solutionWeapon) && !tempCard.equals(solutionLocation)) {
				deckToDeal.add(tempCard);
				numCards++;
			}
		}

		// builds the player queue
		for (Player tempPlayer: playersSet) { // loop through each player and gives them one card
			playerQueue.add(tempPlayer);
		}

		// Deals the deck randomly
		int randIndex = 0;
		Random rand = new Random();
		while (numCards > 0) { // deals cards until no cards left to deal
			// checks number of cards with in for loop 
			if (numCards <= 0) {
				break;
			}
			randIndex = rand.nextInt(numCards); 

			// shifts queue until you have random card at head of queue
			for (int i = 0; i < randIndex; i++) {
				deckToDeal.add(deckToDeal.remove()); // moves first to end (gets "back in line")
			}
			playerQueue.peek().updateHand(deckToDeal.remove()); // Deals card and adds it to Player Object while removing from queue
			playerQueue.add(playerQueue.remove());
			numCards--;
		}
		Player.initializeAllPossibleSets();
	}

	// for testing the handle suggestion method
	public void setPlayersSet(Set<Player> newPlayers) {
		this.playersSet = newPlayers;

		// clears and adds players to queue if new set of players added for testing
		playerQueue.clear();
		for(Player tempPlayer: newPlayers) {
			playerQueue.add(tempPlayer);
		}

	}

	// takes in an accusation array of 3 cards and checks if it is game solution
	public boolean checkAccusation(Card[] possibleSolution) {
		for(Card cardToCheck: possibleSolution) {  //loops through both arrays to see if at least one card is the same for each card
			boolean foundOneCommon = false;
			for(Card solutionCard: solution) {
				if(solutionCard.equals(cardToCheck)) {
					foundOneCommon = true;
				}
			}
			if(Boolean.FALSE.equals(foundOneCommon)) {
				return false;
			}
		}
		return true;
	}

	public Card handleSuggestion(Card[] suggestion, Player suggestor) {
		Queue<Player> copyPlayerQueue = new LinkedList<>();
		copyPlayerQueue.addAll(playerQueue);
		
		//prints the suggestion to game control panel and shows color of suggestor player
		Board.getInstance().window.getGameControlPanel().setGuess(suggestion[0].getCardName() + ", "+ suggestion[1].getCardName() + ", " + suggestion[2].getCardName(), suggestor.getColor());
		//loop through players
		for(int i = 0; i < playersSet.size(); i++) {
			Player tempPlayer = copyPlayerQueue.remove();
			
			// if its the currentPlayer (ie the suggester), move to next person
			if(tempPlayer.equals(suggestor)) {
				continue;
			}
			
			//checks if first seen suggestion common card occurs
			Card disproveCard = tempPlayer.disproveSuggestion(suggestion);
			if( disproveCard != null) {
				// if its human player, print card that disproved the suggestion and add to seen deck
				if (suggestor.isHumanPlayer()) {
					window.getGameControlPanel().setGuessResult(disproveCard.getCardName(), suggestor.getColor()); // shows guess result and suggestor color 
					tempPlayer.addToSeenDeck(disproveCard);
					window.setSeenCard(disproveCard);
					repaint();
					revalidate();
					
				}
				// if its a computer, say that the computer suggestion was disproved
				else {
					tempPlayer.addToSeenDeck(disproveCard);
					window.getGameControlPanel().setGuessResult("Suggestion was disproved", suggestor.getColor()); //message if disproved and color of suggestor
				}
				return tempPlayer.disproveSuggestion(suggestion);
			}
			else {
				window.getGameControlPanel().setGuessResult("Suggestion was NOT disproved", suggestor.getColor()); //message if not disproved and color of suggestor
				continue;
			}
		}
		return null; // returns null for testing
	}

	public Map<String, Room> getRoomMap() {
		return roomMap;
	}

	// called in ClueGame constructor to display the human player's name and the starting message
	public void displayStartingMessage(JFrame frame) {
		for(Player player: playersSet) { // loops through all players until human is found and displays the following message about the player name
			if(player.isHumanPlayer()) {
				String messageToDisplay = "You are " + player.getPlayerName().trim() +". Can you find the solution before the Computer players?" ;
				JOptionPane.showMessageDialog(frame,messageToDisplay,"Welcome to Clue",JOptionPane.WARNING_MESSAGE);  
			}
		}
	}



	public BoardCell[][] getGrid() {
		return grid;
	}



	//paints everything on the board (players, rooms walkways, etc)
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		//looping through grid
		for(int rowIterator = 0; rowIterator < numRows; rowIterator++) {
			for(int colIterator = 0; colIterator < numCols; colIterator++) {
				grid[rowIterator][colIterator].drawCells(g, getWidth(), getHeight()); //calls boardcell draw with widht and height of panel
			}
		}

		//
		if(!targets.isEmpty() && currentPlayer.isHumanPlayer() ) {
			for (BoardCell target : targets) {
				target.drawTargets(g, getWidth(), getHeight());
			}
		}

		//looping for doors to avoid drawing over 
		for(int rowIterator = 0; rowIterator < numRows; rowIterator++) {
			for(int colIterator = 0; colIterator < numCols; colIterator++) {
				grid[rowIterator][colIterator].drawDoors(g, getWidth(), getHeight()); //calls boardcell draw with widht and height of panel
			}
		}
		
		//loop through player list 
		for(Player tempPlayer: playersSet) {
			tempPlayer.setNumRowsCols(numRows, numCols); //setting rows and columns
			Boolean hasMultiplePeople = false;

			for (Player checkSameLoc: playersSet) {
				if (checkSameLoc.equals(tempPlayer)) {
					continue;
				}
				
				if (checkSameLoc.getStartLocation().equals(tempPlayer.getStartLocation())) {
					
				}
			}


			tempPlayer.drawPlayers(g, getWidth(), getHeight(), tempPlayer.getShiftValue());
		}
	}
	
	// loops through all cells and sets if the cell is occupied accordingly
	public void initializeOccupied() {
		for (int r = 0; r < Board.getInstance().getNumRows(); r++) {
			for (int c = 0; c < Board.getInstance().getNumColumns(); c++) {
				grid[r][c].setOccupied(false);
				for (Player player : playerQueue) {
					if (player.getStartLocation()[0] == r && player.getStartLocation()[1] == c) {
						grid[r][c].setOccupied(true);
					}
				}
			}
		}
	}

	// Generic Function for initializing the turns
	public void handleTurn() {
		currentPlayer.setShiftValue(0);
		int roll = currentPlayer.rollDice();
		window.getGameControlPanel().setTurn(currentPlayer.getPlayerName(), roll, currentPlayer.getColor());
		// roll the die and calculates and displays targets
		this.calcTargets(grid[playerQueue.peek().getStartLocation()[0]][playerQueue.peek().getStartLocation()[1]], roll);
		//grid[currentPlayer.getStartLocation()[0]][currentPlayer.getStartLocation()[1]].setOccupied(false);
	}

	//Handles Humans Turn
	public void handleHumansTurn() {
		nextWasPressed = false;
		isHumansTurn = true;
		currentPlayer.setDoneWithTargetSelection(false);
		currentPlayer.setDoneWithTurn(false);
		handleTurn();
		isHumansTurn = false;
		
	}

	// Handles Computers Turn
	public void handleComputersTurn() {

		//seeing if can make accusation
		if(((ComputerPlayer)currentPlayer).canAccuse()) {
			String computerWinText = "Computer Wins.";
			endGame(computerWinText);
		}
		handleTurn();
		BoardCell randomlyChosenTarget = currentPlayer.selectTarget(targets);
		currentPlayer.movePlayerToNewLoc(randomlyChosenTarget);
		
		// if the computer enters a room, generate a Suggestion
		if (randomlyChosenTarget.isARoom()) {
			
			// creates suggestion and SHOULD move corresponding player to the room that was suggested
			Card[] computerSuggestion = currentPlayer.createSuggestion(randomlyChosenTarget.getRoom().getName());
			
			// returns disproved card and adds card to seen deck
			Card cardDisprove = handleSuggestion(computerSuggestion, currentPlayer);
		}
	}




	// Generic function for displaying pop-up error message
	public void displayErrorMessage(String message) {
		JOptionPane.showMessageDialog(this,message,"ERROR",JOptionPane.ERROR_MESSAGE);  
	}
	
	// HANDLE THE EVENT OF NEXT BUTTON:
	public void nextButtonPressed() {
		if (!Board.getInstance().currentPlayer.isDoneWithTurn()) {
			displayErrorMessage("Turn is not over");
		}
		else {
			Board.getInstance().playerQueue.add(Board.getInstance().playerQueue.remove());
			currentPlayer = playerQueue.peek();
			if (playerQueue.peek().isHumanPlayer()) {
				handleHumansTurn();
			}
			else {
				handleComputersTurn();
			}
		}
	}
	
	public void accusationIsPressed() {
		// if it is human players turn...
		if (!currentPlayer.isDoneWithTurn() && currentPlayer.isHumanPlayer()) {
			//TODO: Pull up accusation window and check accusation, if player
			SuggestAccuseDialogBox dBox = new SuggestAccuseDialogBox(DialogType.ACCUSATION, new Room("null"));
			dBox.setObjects(deck);
			dBox.createBox();
			dBox.setVisible(true);
		}
		else {
			displayErrorMessage("You must wait for your turn to make an accusation");
		}
	}
	
	//function called when mouse is clicked and current player is human
	// encapsulated in its own method so that we can simplify the mouseClicked method, which will 
	// probably be used in the future for accusations
	public void handleHumanTargetSelection(MouseEvent e) {
		Point clickLoc = e.getPoint();
		boolean clickedTarget = false;
		for (BoardCell target : getTargets()) {
			if (target.getRect().contains(clickLoc) && currentPlayer.isDoneWithTargetSelection() == false) {
				currentPlayer.movePlayerToNewLoc(target);
				//target.setOccupied(true);
				clickedTarget = true;
				currentPlayer.setDoneWithTargetSelection(true);
				targets.clear();
				// if moved to a room, open suggestion window
				if (grid[currentPlayer.getStartLocation()[0]][currentPlayer.getStartLocation()[1]].isARoom()) {
					//opens suggestion window
					currentPlayer.setCurrentlyMakingSuggestion(true);
					SuggestAccuseDialogBox dBox = new SuggestAccuseDialogBox(DialogType.SUGGESTION, grid[currentPlayer.getStartLocation()[0]][currentPlayer.getStartLocation()[1]].getRoom());
					dBox.setObjects(deck);
					dBox.createBox();
					dBox.setVisible(true);
					// Pass in grid[currentPlayer.getStartLocation()[0]][currentPlayer.getStartLocation()[1]].getRoom(); for room they are in
				}
				currentPlayer.setDoneWithTurn(true);

				//can potentially handle suggestions here later
				break;
			}
		}
		if (clickedTarget == false && !currentPlayer.isDoneWithTargetSelection()) {
			displayErrorMessage("Not a valid target");
		}
		if(clickedTarget == true && !currentPlayer.isDoneWithTargetSelection()) {
			displayErrorMessage("You already selected your target");
		}
	}

	// HANDLES EVENT OF MOUSE IS CLICKED
	@Override
	public void mouseClicked(MouseEvent e) {

		// If currentPlayer is Human
		if (currentPlayer.isHumanPlayer()) {
			// handles clicking on target
			handleHumanTargetSelection(e);
		}
	}


	// unused but needed ovveride functions from the interfaces 
	@Override
	public void mousePressed(MouseEvent e) {}
	@Override
	public void mouseReleased(MouseEvent e) {}
	@Override
	public void mouseEntered(MouseEvent e) {}
	@Override
	public void mouseExited(MouseEvent e) {}
	
	/////SETTERS:

	// File names setters
	public void setConfigFiles(String layoutFile, String setupFile) {
		this.layoutConfigFile = "data/" + layoutFile;
		this.setupConfigFile = "data/" + setupFile;
	}
	public void setSolution(Card[] gameSolution) {
		solution = gameSolution;
	}
	public void setPlayerQueue(Queue<Player> playerQueue) {
		this.playerQueue = playerQueue;
	}
	public void setIsHumansTurn(Boolean isHumansTurn) {
		this.isHumansTurn = isHumansTurn;

	}

	//GETTERS:
	public Boolean deckContainsCard(Card card) {

		for(Card tempCard: deck) {
			if (tempCard.equals(card)) {
				return true;
			}
		}
		return false;
	}
	public Boolean playersSetContains(Player player) {

		for(Player tempPlayer: playersSet) {
			if(tempPlayer.getPlayerName().trim().equals(player.getPlayerName().trim())) {
				return true;
			}
		}
		return false;
	}
	public Room getRoom(BoardCell inputCell) {
		return roomMap.get(inputCell.getInitial());
	}

	public Room getRoom(String inital) {
		return roomMap.get(inital);
	}

	public ArrayList<String> getRoomNames() {
		return roomNames;
	}

	public BoardCell getCell(int row, int col) {
		return grid[row][col];
	}

	public int getNumRows() {
		return numRows;
	}
	public int getNumColumns() {
		return numCols;
	}
	public Set<BoardCell> getAdjList(int r, int c){
		return getCell(r,c).getAdjListFromCell();
	}
	public Set<BoardCell> getTargets() {
		return targets;
	}
	public Boolean solutionIsValid() {
		if(solution[0].getCardType() != solution[1].getCardType() && solution[0].getCardType() != solution[2].getCardType() && solution[1].getCardType() != solution[2].getCardType()) {
			return true;
		}
		return false;
	}

	public Card[] getSolution() {
		return solution;
	}

	public Set<Player> getPlayersSet() {
		return playersSet;
	}

	public Boolean getIsHumansTurn() {
		//if (playerQueue.)
		return isHumansTurn;
	}
	public Queue<Player> getPlayerQueue() {
		return playerQueue;
	}
	
	
	public Player getCurrentPlayer() {
		return currentPlayer;
	}


	public void setCurrentPlayer(Player currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	// Handles making the board and initialization of the game and starts the human players turn
	public static void main(String[] args) {
		Board instance = Board.getInstance();
		instance.window = new ClueGame(800,800);
		// make sure player starts 
		while (instance.getPlayerQueue().peek().isHumanPlayer() != true) {
			instance.getPlayerQueue().add(instance.playerQueue.remove());
		}
		// should have human at head of the queue now. Set this as current player
		instance.currentPlayer = instance.getPlayerQueue().peek();
		instance.currentPlayer.setDoneWithTurn(false);

		// add the players card to in hand
		for(Card card : instance.getPlayerQueue().peek().getPlayerCards()) {
			instance.window.setHandCard(card);
		}

		// now everything is displaying, handle the humans turn
		instance.handleHumansTurn();
		instance.setVisible(true);

	}

	//returns the deck with all cards
	public Set<Card> getDeck() {
		return deck;
	}

	//sets the deck of all cards
	public void setDeck(Set<Card> deck) {
		this.deck = deck;
	}
	
	//when called, will close the frame (ClueGame/window) and terminate the program. Called if either way when accusation occurs
	public void endGame(String message) {
		
		message += " Game Solution: " + this.solution[0].getCardName() + ", "
		+ this.solution[1].getCardName() + ", " + this.solution[2].getCardName() + ".";
		JOptionPane.showMessageDialog(this,message,"Game Over",JOptionPane.INFORMATION_MESSAGE);  
		window.dispose();
		window.setVisible(false);
	}


	public ClueGame getWindow() {
		return window;
	}


	public void setWindow() {
		window = new ClueGame(800,800);
	}
	
	
}
