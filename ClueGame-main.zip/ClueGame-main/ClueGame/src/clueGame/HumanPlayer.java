package clueGame;
/*
 * Authors: Calla Winner and Scott Williams
 * Human player is a child of Player and is used to handle the the player actions
 * for the person actually playing the game. 
 */
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;


public class HumanPlayer extends Player{
	
	public HumanPlayer(String playerName, String color, int[] startLocation) {
		super(playerName, color, startLocation);
	}

	@Override
	public Card[] createSuggestion(String roomName) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public BoardCell selectTarget(Set<BoardCell> targets) {
		return null;
	}

	//always returns true because in human player extension class
	@Override
	public Boolean isHumanPlayer() {
		return true;
	}

	

}
