package clueGame;
/*
 * Card is used to store info about weapons, people, and rooms. It also holds the color to be drawn. 
 */
import java.awt.Color;

public class Card {
	private String cardName;
	private CardType cardType;
	private Color cardColor;
	
	public Card(String cardName, CardType cardType) {
		super();
		this.cardName = cardName;
		this.cardType = cardType;
	}
	
	
	public Boolean equals(Card target) {
		if (target.getCardName().equals(this.cardName) && target.getCardType().equals(this.cardType)) {
			return true;
		}
		return false;
	}


	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public void setCardType(CardType cardType) {
		this.cardType = cardType;
	}
	
	public String getCardName() {
		return cardName;
	}
	
	public CardType getCardType() {
		return cardType;
	}
	
	// need color for card when adding cards to gui. hence the setters and getters
	public void setCardColor(Color color) {
		cardColor = color;
	}
	
	public Color getCardColor() {
		return cardColor;
	}



}
