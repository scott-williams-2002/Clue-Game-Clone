package clueGame;

/**
 * Authors: Calla Winner and Scott Williams
 * Description:
 * This class represents a room and its associated information. The methods still need to 
 * be implemented and are skeleton methods for testing. 
 * 
 */
public class Room {
	private String name;
	private BoardCell centerCell;
	private BoardCell labelCell;
	
	
	public Room(String newName) {
		super();
		this.name = newName;
	}

	// 4 following methods are getters and setters for boardcells
	public BoardCell getCenterCell() {
		return centerCell;
	}

	public void setCenterCell(BoardCell centerCellInput) {
		this.centerCell = centerCellInput;
	}

	public BoardCell getLabelCell() {
		return labelCell;
	}

	public void setLabelCell(BoardCell labelCellInput) {
		this.labelCell = labelCellInput;
	}
	
	// returns room name
	public String getName() {
		return name; 
	}
	
	
}
