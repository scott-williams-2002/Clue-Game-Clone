/*
 * ClueGame class
 * Authors: Calla Winner and Scott Williams
 * The main of this class assembles the frame and adds all panels accordingly
 */

package clueGame;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;



public class ClueGame extends JFrame implements MouseListener, ActionListener{

//public class ClueGame extends JFrame{


	//3 custom panels
	private GameControlPanel gameControlPanel;
	private KnownCardsPanel knownCardsPanel;
	private static Board board; 

	//dimensions of frame to ensure the size can change later
	private int frameWidth;
	private int frameHeight;
	private Point clickLoc;

	// sets width and height of the frame 
	public ClueGame(int width, int height) {

		// setting tiele and dimensions
		setTitle("Clue Game: By Calla and Scott");
		frameWidth = width;
		frameHeight = height;
		setSize(new Dimension(frameWidth, frameHeight));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//layout for 3 panels
		setLayout(new BorderLayout());


		//getting instances of the 3 types of panels and adding them to their location in border layout
		board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
		board.initialize();
		gameControlPanel = new GameControlPanel();  //takes this as an argument to set actionlistener for button
		knownCardsPanel = new KnownCardsPanel();

		//showing first message
		board.displayStartingMessage(this);
		board.addMouseListener(board);
		add(board, BorderLayout.CENTER);
		add(gameControlPanel, BorderLayout.SOUTH);
		add(knownCardsPanel, BorderLayout.EAST);
		setVisible(true);

	}

	//adds cards from frame 
	public void setSeenCard(Card card) {
		knownCardsPanel.addSeenCard(card);
	}
	public void setHandCard(Card card) {
		knownCardsPanel.addCardToHand(card);
	}
	

	//sets current player and roll
	public void setCurrentPlayer(Player currentPlayer) {
		gameControlPanel.setTurn(currentPlayer.getPlayerName(), currentPlayer.getRoll(), currentPlayer.getColor());
	}
	

	public GameControlPanel getGameControlPanel() {
		return gameControlPanel;
	}
	
	
	

	// needed for interface but not implemented here at the moment
	@Override
	public void actionPerformed(ActionEvent e) {}
	@Override
	public void mouseClicked(MouseEvent e) {}
	@Override
	public void mousePressed(MouseEvent e) {}
	@Override
	public void mouseReleased(MouseEvent e) {}
	@Override
	public void mouseEntered(MouseEvent e) {}
	@Override
	public void mouseExited(MouseEvent e) {}

}
