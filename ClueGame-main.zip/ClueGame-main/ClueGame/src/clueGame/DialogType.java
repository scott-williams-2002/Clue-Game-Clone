package clueGame;
/**
 * Authors: Calla Winner and Scott Williams
 * Description:
 * This enum represents the type of dialog box for suggestion or accusation.
 * 
 */
public enum DialogType {
	SUGGESTION,
	ACCUSATION;
}
