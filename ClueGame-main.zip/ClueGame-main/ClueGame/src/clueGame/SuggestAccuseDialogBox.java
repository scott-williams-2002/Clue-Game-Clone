package clueGame;
/*
 * Authors: Calla Winner and Scott Williams
 * Class used to handle the pop up and drop down menu for a suggestion or accusation and trigger events 
 * handled by board accordingly. 
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;


public class SuggestAccuseDialogBox extends JDialog implements ItemListener, ActionListener{
	private DialogType dialogType;
	private Room currentRoom;
	private JComboBox roomComboBox;
	private JComboBox weaponComboBox;
	private JComboBox personComboBox;
	private ArrayList<String> roomNames;
	private ArrayList<String> weaponNames;
	private ArrayList<String> personNames;
	private JPanel leftSide;
	private JPanel rightSide;
	private JButton submitButton;
	private JButton cancelButton;
	private Set<Card> cardDeck;
	private String[] outputNameArray;

	//constructor used for setting buttons, text, panels, and event listeners
	public SuggestAccuseDialogBox(DialogType dialogType, Room currentRoom) {
		super();
		setSize(300,200);
		this.dialogType = dialogType;
		this.currentRoom = currentRoom;
		roomNames = new ArrayList<>();
		weaponNames = new ArrayList<>();
		personNames = new ArrayList<>();

		//setting layout
		setLayout(new GridLayout(1,2));
		leftSide = new JPanel();
		rightSide = new JPanel();
		leftSide.setLayout(new GridLayout(4,1));
		rightSide.setLayout(new GridLayout(4,1));
		add(leftSide);
		add(rightSide); //adding both sides

		//setting up buttons
		submitButton = new JButton();
		cancelButton = new JButton();
		submitButton.setText("Submit");
		cancelButton.setText("Cancel");
		//setting the action listener to buttons
		submitButton.addActionListener(this);
		cancelButton.addActionListener(this);


		//setting space of 3 items in the output array
		outputNameArray = new String[3];
	}

	// takes all cards in play and uses for dialog box
	public void setObjects(Set<Card> allCards) {
		cardDeck = allCards;
		for(Card card : allCards) {
			if(card.getCardType() == CardType.ROOM) {
				roomNames.add(card.getCardName());
			}
			if(card.getCardType() == CardType.WEAPON) {
				weaponNames.add(card.getCardName());
			}
			if(card.getCardType() == CardType.PERSON) {
				personNames.add(card.getCardName());
			}
		}
		roomComboBox = new JComboBox(roomNames.toArray());
		weaponComboBox = new JComboBox(weaponNames.toArray());
		personComboBox = new JComboBox(personNames.toArray());
	}

	//seperates drawing tasks to each method based on type then draws button to each
	public void createBox() {
		if(dialogType == DialogType.ACCUSATION) {
			drawAccusationBox();
		}
		if(dialogType == DialogType.SUGGESTION) {
			drawSuggestionBox();
		}
	}

	// draws JDialog for accusations
	public void drawAccusationBox() {
		this.setTitle("Make an Accusation"); //sets title/ instructions for dialog
		rightSide.add(roomComboBox); // adding the drop downs in order
		rightSide.add(personComboBox);
		rightSide.add(weaponComboBox); 

		// now adding Jtext fields to left
		JTextField roomText = new JTextField();
		JTextField personText = new JTextField();
		JTextField weaponText = new JTextField();
		roomText.setText("Room");
		personText.setText("Person"); //setting their text to be displayed
		weaponText.setText("Weapon");
		leftSide.add(roomText);
		leftSide.add(personText); //adding to left panel
		leftSide.add(weaponText);

		//adding buttons after adding all unique info
		leftSide.add(submitButton);
		rightSide.add(cancelButton);
	}

	//draws JDialog for suggestions
	public void drawSuggestionBox() {
		this.setTitle("Make an Suggestion"); //sets title/ instructions for dialog
		JTextField currentText = new JTextField();
		currentText.setText(currentRoom.getName().trim());

		rightSide.add(currentText); // current room text added
		rightSide.add(personComboBox); //and adding the drop downs in order
		rightSide.add(weaponComboBox); 

		// now adding Jtext fields to left
		JTextField roomText = new JTextField();
		JTextField personText = new JTextField();
		JTextField weaponText = new JTextField();
		roomText.setText("Current Room");
		personText.setText("Person"); //setting their text to be displayed
		weaponText.setText("Weapon");
		leftSide.add(roomText);
		leftSide.add(personText); //adding to left panel
		leftSide.add(weaponText);

		//adding buttons
		leftSide.add(submitButton);
		rightSide.add(cancelButton);
	}

	//unused needed for listener
	@Override
	public void itemStateChanged(ItemEvent e) {}

	//method maps strings to card objects and returns an array of 3 cards
	public Card[] getReturnedCards() {
		int roomIndex = 0;
		int personIndex = 1;
		int weaponIndex = 2;

		//gets drop down input into an array
		if(dialogType == DialogType.ACCUSATION) {
			outputNameArray[roomIndex] = (String) roomComboBox.getSelectedItem();
			outputNameArray[personIndex] = (String) personComboBox.getSelectedItem();  //every time the drop down in changed, the array updates
			outputNameArray[weaponIndex] = (String) weaponComboBox.getSelectedItem();
		}
		if(dialogType == DialogType.SUGGESTION) {
			outputNameArray[roomIndex] = currentRoom.getName().trim();
			outputNameArray[personIndex] = (String) personComboBox.getSelectedItem();  //every time the drop down in changed, the array updates
			outputNameArray[weaponIndex] = (String) weaponComboBox.getSelectedItem();
		}

		Card[] returnedCards = new Card[3];

		//looping through all cards to convert string names to card Array
		for (Card checkedCard: cardDeck) {
			if(checkedCard.getCardName().equals(outputNameArray[roomIndex])) {
				returnedCards[roomIndex] = checkedCard;
			}
			if(checkedCard.getCardName().equals(outputNameArray[personIndex])) {
				returnedCards[personIndex] = checkedCard;
			}
			if(checkedCard.getCardName().equals(outputNameArray[weaponIndex])) {
				returnedCards[weaponIndex] = checkedCard;
			}
		}
		return returnedCards;
	}

	//handles submit and cancel buttons for JDialog
	@Override
	public void actionPerformed(ActionEvent e) {
		Card[] retCards = getReturnedCards();
		Card cardDisprove;
		//gets rid of window and makes invisible if cancel is pressed
		if(e.getSource().equals(cancelButton)) {
			this.dispose();
			setVisible(false);


		}
		if(e.getSource().equals(submitButton)) {
			if(dialogType == DialogType.SUGGESTION) {
				dispose(); 
				setVisible(false); //gets rid of window after button hit
				cardDisprove = Board.getInstance().handleSuggestion(retCards, Board.getInstance().getCurrentPlayer());
			}
			//since this is only used for human player no need to check 
			if(dialogType == DialogType.ACCUSATION) {
				boolean accusationCorrect = Board.getInstance().checkAccusation(retCards);
				if(accusationCorrect) {
					// ends game and displays text
					String winText = "Congratulations " + Board.getInstance().getCurrentPlayer().getPlayerName() +". You Won!";
					Board.getInstance().endGame(winText);
					//prints dialog box with result of game accordingly
				}else {
					String looseText = "Sorry " + Board.getInstance().getCurrentPlayer().getPlayerName() +". You Lost!";
					Board.getInstance().endGame(looseText); //ends game and displays loosing text
				}
				// moves cards according to suggestions
				for (Player player : Board.getInstance().getPlayerQueue()) {
					if (player.getPlayerName().trim().equals(retCards[1].getCardName().trim())) {
						Board.getInstance().getCurrentPlayer().moveToLocation(player);
					}
				}

				//then removes itself from the board
				dispose(); 
				setVisible(false);

			}

		}
	}
}


