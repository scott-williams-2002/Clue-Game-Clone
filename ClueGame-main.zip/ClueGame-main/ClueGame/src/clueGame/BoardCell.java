package clueGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.util.HashSet;
import java.util.Set;
import java.awt.Rectangle;
import java.awt.*;
import javax.swing.JLabel;

/**
 * Authors: Calla Winner and Scott Williams
 * Description:
 * This object represents each cell in the board. It has variables that store various
 * pieces of information such as the symbol, location, and if its a room. There are also
 * some getters/setters that have not been implemented yet for testing. 
 * 
 */

public class BoardCell {
	private Board board;
	private int row;
	private int col;
	private String initial;
	private DoorDirection doorDirection;
	private boolean roomLabel;
	private boolean roomCenter;
	private boolean isRoom;
	private boolean isOccupied;
	private String secretPassage;
	private Set<BoardCell> adjList = new HashSet<>();
	private Room room;
	private Rectangle rect;

	//for drawing and resizing
	private int squareWidth;
	private int squareHeight;

	//gives information about board dimensions
	private int boardRows;
	private int boardCols;
	
	
	// Constructor
	public BoardCell(int row, int col) {
		super();
		board = Board.getInstance();
		this.row = row;
		this.col = col;
	}

	// boolean functions:
	public boolean isLabel() {
		return roomLabel; //set to false for tests
	}

	public boolean isRoomCenter() {
		return roomCenter; //set to false for tests
	}

	public boolean isDoorway() {
		if (doorDirection == DoorDirection.NONE) {
			return false;
		}
		return true;
	}

	public boolean isWalkway() {
		if (initial.equals("W")) {
			return true;
		}
		return false;
	}

	// Setters

	public void setInitial(String cellInitial) {
		if (cellInitial.contains("#")) {
			this.roomLabel = true;
			cellInitial = cellInitial.substring(0, cellInitial.length() - 1).trim(); // gets rid of #
		}
		if (cellInitial.contains("*")) {
			this.roomCenter = true;
			cellInitial = cellInitial.substring(0, cellInitial.length() - 1).trim();// gets rid of *
		}
		if (cellInitial.contains("<")) {
			doorDirection = DoorDirection.LEFT;
			cellInitial = cellInitial.substring(0, cellInitial.length() - 1).trim();// gets rid of <
		}
		else if (cellInitial.contains(">")) {
			doorDirection = DoorDirection.RIGHT;
			cellInitial = cellInitial.substring(0, cellInitial.length() - 1).trim();// gets rid of >
		}
		else if (cellInitial.contains("^")) {
			doorDirection = DoorDirection.UP;
			cellInitial = cellInitial.substring(0, cellInitial.length() - 1).trim();// gets rid of ^
		}
		else if (cellInitial.contains("v")) {
			doorDirection = DoorDirection.DOWN;
			cellInitial = cellInitial.substring(0, cellInitial.length() - 1).trim();// gets rid of v
		}
		else {
			doorDirection = DoorDirection.NONE;
		}
		this.initial = cellInitial.trim(); 
	}

	public void setAdjMtx( Set<BoardCell> adjMtx) {
		this.adjList = adjMtx;
	}

	public void addToAdjMtx( BoardCell adjCell) {
		this.adjList.add(adjCell);
	}


	public void setSecretPassage(Boolean isPassage) {
		if (Boolean.TRUE.equals(isPassage)) {
			secretPassage = this.initial.substring(this.initial.length()/2).trim(); 
			initial = this.initial.substring(0, this.initial.length()/2).trim(); 
		}
		else {
			secretPassage = null;
		}
	}

	// sets occupied to true or false if player is on cell
	public void setOccupied(boolean isCellOccupied) {
		this.isOccupied = isCellOccupied;
	}

	public void setIsRoom() {
		if (this.initial.equals("W") || this.initial.equals("X")){
			isRoom = false;
		}
		else {
			isRoom = true;
		}

	}

	public void setNumRowsCols(int rows, int cols) {
		boardRows = rows;
		boardCols = cols;
	}

	// draws each cell
	public void drawCells(Graphics g, int panelWidth, int panelHeight) {
		// used for drawing differnt types of cells
		Color lightBlue = new Color(153,205,255);
		             //need to set color before editing graphic
		double width = (panelWidth / boardRows);
		double height = (panelHeight / boardCols);
		//int borderBuffer = 5;  //width of border around cells that will have border

		int yLocation = (int) (height * row);
		int xLocation = (int) (width * col);
		setRect(new Rectangle(xLocation, yLocation, (int)width, (int)height));
		
		if(isRoom) {
			
			if (board.getTargets().contains(this) && board.getPlayerQueue().peek().isHumanPlayer()) {
				
				g.setColor(Color.YELLOW);
			}
			else {
				g.setColor(lightBlue);
			}
			//g.setColor(lightBlue);
			g.fillRect(xLocation, yLocation, (int)width, (int)height);
		}
		else if(isWalkway()) {
			g.setColor(Color.GRAY);
			g.fillRect(xLocation, yLocation, (int)width, (int)height);
			g.setColor(Color.BLACK);
			g.drawRect(xLocation, yLocation, (int)width, (int)height);
			
			
		}
		else {
			g.setColor(Color.DARK_GRAY);
			g.fillRect(xLocation, yLocation, (int)width, (int)height);
		}
	}
	
	//draw door draws all doors after the cells are all drawn to prevent being drawn over
	public void drawDoors(Graphics g, int panelWidth, int panelHeight) {
		double doorWidth = 0.25;
		double width = (panelWidth / boardRows);
		double height = (panelHeight / boardCols);
		int yLocation = (int) (height * row);
		int xLocation = (int) (width * col);
		Color doorColor = new Color(255, 102, 0);
		
		//draws door directions according to their location
		if(isDoorway()) {
			if(doorDirection == DoorDirection.UP) {
				g.setColor(doorColor);
				g.fillRect(xLocation, yLocation - (int)(doorWidth * height), (int)width, (int)(doorWidth * height));  //draws from top left to top left + 1/4 of the y
			}
			if(doorDirection == DoorDirection.DOWN) {
				g.setColor(doorColor);
				g.fillRect(xLocation, yLocation + (int)height, (int)width, (int)(doorWidth * height)); //draws from cell top left to cell beneath top left corner
			}
			if(doorDirection == DoorDirection.LEFT) {
				g.setColor(doorColor);
				g.fillRect(xLocation - (int)(doorWidth * width), yLocation , (int) (width * doorWidth), (int)(height));
			}
			if(doorDirection == DoorDirection.RIGHT) {
				g.setColor(doorColor);
				g.fillRect(xLocation + (int)width, yLocation , (int) (width * doorWidth), (int)(height));
			}
		}
		
		// sets text type size and location
		if(isLabel()) {
			g.setColor(Color.DARK_GRAY);
			g.setFont(new Font("Calibri", Font.PLAIN, 12)); 
			g.drawString(room.getName(), xLocation, yLocation);
		}
		
	}
	
	public void drawTargets(Graphics g, int panelWidth, int panelHeight) {
		double width = (panelWidth / boardRows);
		double height = (panelHeight / boardCols);
		int yLocation = (int) (height * row);
		int xLocation = (int) (width * col);
		g.setColor(Color.YELLOW);
		g.fillRect(xLocation, yLocation, (int)width, (int)height);
	}
	//Getters

	//returns true if occupied
	public boolean isOccupied() {
		return isOccupied;
	}
	public String getInitial() {
		return initial;
	}
	public DoorDirection getDoorDirection() {
		return doorDirection;
	}
	public String getSecretPassage() {
		return secretPassage; 
	}
	public Set<BoardCell> getAdjListFromCell() {
		return adjList;
	}
	public boolean isARoom() {
		return isRoom;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public Rectangle getRect() {
		return rect;
	}

	public void setRect(Rectangle rect) {
		this.rect = rect;
	}
	
	public int[] getLocation() {
		int[] loc = {row, col};
		return loc;
	}



}
