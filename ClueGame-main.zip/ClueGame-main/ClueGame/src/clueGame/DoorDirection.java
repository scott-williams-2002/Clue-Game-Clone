package clueGame;
/**
 * Authors: Calla Winner and Scott Williams
 * Description:
 * This enum represents the direction a doorway can open. 
 * 
 */
public enum DoorDirection {
	UP, 
	DOWN,
	LEFT,
	RIGHT,
	NONE;
}
