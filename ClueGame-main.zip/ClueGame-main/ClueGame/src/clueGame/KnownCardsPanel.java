package clueGame;
/*
 * Authors: Scott Williams and Calla Winner
 * This method is an extension of a JPanel and is used to display 
 * The cards in the player's hand and which were seen from other players.
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;


public class KnownCardsPanel extends JPanel{
	private JPanel seenPeople;
	private JPanel handPeople;
	private JPanel seenRooms;
	private JPanel handRooms;
	private JPanel seenWeapons;
	private JPanel handWeapons;
	private Set<Card> handCards;
	private Set<Card> seenCards;
	

	public KnownCardsPanel() {
		//initializing panels for all cards that need to be updated later
		seenPeople = new JPanel();
		handPeople = new JPanel();
		seenRooms = new JPanel();
		handRooms = new JPanel();
		seenWeapons = new JPanel();
		handWeapons = new JPanel();
		
		//setting layout given dimension for each panel
		handPeople.setLayout(new GridLayout(0, 1));
		handRooms.setLayout(new GridLayout(0, 1));
		handWeapons.setLayout(new GridLayout(0,1));
		seenPeople.setLayout(new GridLayout(0, 1));
		seenRooms.setLayout(new GridLayout(0, 1));
		seenWeapons.setLayout(new GridLayout(0, 1));
		
		// initializing arraylists of cards seen and in hand
		handCards = new HashSet<>();
		seenCards = new HashSet<>();

		// set panel layout to border type 
		setLayout(new GridLayout(3,1));
		setBorder(BorderFactory.createTitledBorder("Known Cards"));

		//creating 3 panels one for each type of card seen
		JPanel panelOne = new JPanel();
		JPanel panelTwo = new JPanel();
		JPanel panelThree = new JPanel();

		// calling function to set various info about each panel
		addPanelInfo(panelOne, CardType.PERSON);
		addPanelInfo(panelTwo, CardType.ROOM);
		addPanelInfo(panelThree, CardType.WEAPON);

		// sets the border with name of panel 
		panelOne.setBorder(BorderFactory.createTitledBorder("People"));
		panelTwo.setBorder(BorderFactory.createTitledBorder("Rooms"));
		panelThree.setBorder(BorderFactory.createTitledBorder("Weapons"));

		// adding panels to card panel at given areas of panel
		add(panelOne);
		add(panelTwo);
		add(panelThree);
	}
	
	
	// sets info about each panel and adds cards to the panels by calling their methods. (could add the set layout size here when adding)
	public void addPanelInfo(JPanel panel, CardType type) {

		panel.setLayout(new BorderLayout());

		//if else for types of panels to edit
		if(type == CardType.PERSON) {
			editHandPanel(handPeople, type);
			handPeople.setBorder(BorderFactory.createTitledBorder("In Hand:"));
			panel.add(handPeople, BorderLayout.NORTH);
			editSeenPanel(seenPeople, type);
			seenPeople.setBorder(BorderFactory.createTitledBorder("Seen:"));
			panel.add(seenPeople, BorderLayout.CENTER);
		}
		if(type.equals(CardType.ROOM)) {
			editHandPanel(handRooms, type);
			handRooms.setBorder(BorderFactory.createTitledBorder("In Hand:"));
			panel.add(handRooms, BorderLayout.NORTH);
			editSeenPanel(seenRooms, type);
			seenRooms.setBorder(BorderFactory.createTitledBorder("Seen:"));
			panel.add(seenRooms, BorderLayout.CENTER);
		}
		if(type.equals(CardType.WEAPON)) {
			editHandPanel(handWeapons, type);
			handWeapons.setBorder(BorderFactory.createTitledBorder("In Hand:"));
			panel.add(handWeapons, BorderLayout.NORTH);
			editSeenPanel(seenWeapons, type);
			seenWeapons.setBorder(BorderFactory.createTitledBorder("Seen:"));
			panel.add(seenWeapons, BorderLayout.CENTER);
		}
	}

	// adds card to arraylist of hand cards and display card info
	public void addCardToHand(Card card) {
		handCards.add(card);

		//if else to call edit 
		if(card.getCardType() == CardType.PERSON) {
			editHandPanel(handPeople, card.getCardType());
		}
		if(card.getCardType().equals(CardType.ROOM)) {
			editHandPanel(handRooms, card.getCardType());
		}
		if(card.getCardType().equals(CardType.WEAPON)) {
			editHandPanel(handWeapons, card.getCardType());
		}
	}

	//add to seen card arraylist and display card info
	public void addSeenCard(Card card) {
		seenCards.add(card);

		//if else to call edit 
		if(card.getCardType() == CardType.PERSON) {
			editSeenPanel(seenPeople, card.getCardType());
		}
		if(card.getCardType().equals(CardType.ROOM)) {
			editSeenPanel(seenRooms, card.getCardType());
		}
		if(card.getCardType().equals(CardType.WEAPON)) {
			editSeenPanel(seenWeapons, card.getCardType());
		}
	}


	// loops through the arraylist of cards in hand and draws them to the panel inputted given the type
	public void editHandPanel(JPanel panel, CardType type) {
		int typeCount = 0;  // records cards in panel

		// removes all text fields from panel
		panel.removeAll();

		// if arraylist not empty loops through until finding a card of the correct type then adding text field to panel accordingly 
		if(!handCards.isEmpty()) {
			for(Card card : handCards) {
				if(card.getCardType() == type) {
					typeCount++;


					JTextField addedCard = new JTextField(15);
					addedCard.setText(card.getCardName());
					//adds color to card
					addedCard.setBackground(card.getCardColor());
					panel.add(addedCard);
				}
			}
		}

		// if can't find desired cards, displays none in text field
		if(typeCount == 0) {
			JTextField emptyField = new JTextField(15);
			emptyField.setText("None");
			panel.add(emptyField);
		}
	}

	// loops through the arraylist of cards seen and draws them to the panel inputted given the type
	public void editSeenPanel(JPanel panel, CardType type) {
		int typeCount = 0; //records cards in panel

		// removes all text fields from panel
		panel.removeAll();
		
		// if arraylist not empty loops through until finding a card of the correct type then adding text field to panel accordingly 
		if(!seenCards.isEmpty()) {
			for(Card card : seenCards) {
				if(card.getCardType().equals(type)) {
					typeCount++;

					JTextField addedCard = new JTextField(15);
					addedCard.setText(card.getCardName());
					//adds color to card
					addedCard.setBackground(card.getCardColor());
					panel.add(addedCard);
				}
			}
		}

		// if no desired cards, displays none in text field
		if(typeCount == 0) {
			JTextField emptyField = new JTextField(15);
			emptyField.setText("None");
			panel.add(emptyField);
		}
	}
	
	





}
