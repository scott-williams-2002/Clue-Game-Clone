package clueGame;
/*
 * Authors: Calla Winner and Scott Williams 
 * ComputerPlayer extends player and is used to perform some of the same functionality as player, such as moving
 * and giving suggestions, but it differs in how the targets are chosen and suggestions are made. 
 */
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Set;

public class ComputerPlayer extends Player {

	public ComputerPlayer(String playerName, String color, int[] startLocation) {
		super(playerName, color, startLocation);
	}


	@Override
	public  Card[] createSuggestion(String roomName) {
		ArrayList<Card> suggestion = new ArrayList();
		Card[] suggestionArray = new Card[3];

		// find the card of the room they are in and add it to suggestion

		for (Card roomCard : Player.getAllPossibleRooms()) {

			if (roomCard.getCardName().equals(roomName)) {
				suggestion.add(roomCard);
				break;
			}
		}

		// Select a Weapon
		Set<Card> allKnownWeapons = new HashSet<>();

		allKnownWeapons.addAll(this.getSeenWeapons());
		Random rand = new Random(); 
		Set<Card> allPossibleWeapons = super.getAllPossibleWeapons();
		// remove from set until there is only one left
		for (Card weapon : super.getSeenWeapons()) {
			allPossibleWeapons.remove(weapon);

		}
		for (Card playerDeckCard : super.getPlayerCards()) {
			allPossibleWeapons.remove(playerDeckCard);
		}

		// if it is last card, suggest that card
		if (allPossibleWeapons.size() == 1) {
			for (Card suggestedWeapon : allPossibleWeapons) {
				suggestion.add(suggestedWeapon);
			}
		}
		// if there are multiple weapons left, randomly select one
		else if (allPossibleWeapons.size() > 1){
			Queue<Card> allUnknownWeapons = new LinkedList<>();
			allUnknownWeapons.addAll(allPossibleWeapons);

			while (allUnknownWeapons.size() > 1) {
				int randIndex = rand.nextInt(allUnknownWeapons.size()); 
				for (int i = 0; i < randIndex; i++) {
					allUnknownWeapons.add(allUnknownWeapons.remove()); // puts head of queue at back of queue
				}
				allUnknownWeapons.remove();
			}
			// adds last random card left in queue
			suggestion.add(allUnknownWeapons.peek());
		}

		// Select a person
		Set<Card> allKnownPeople = new HashSet<>();
		allKnownPeople.addAll(this.getSeenPeople()); 
		Set<Card> allPossiblePeople = super.getAllPossiblePeople();
		// remove from set until there is only one left
		for (Card person : super.getSeenPeople()) {
			allPossiblePeople.remove(person);
		}
		for (Card playerDeckCard : super.getPlayerCards()) {
			allPossiblePeople.remove(playerDeckCard);
		}

		// if it is last card, suggest that card
		if (allPossiblePeople.size() == 1) {
			for (Card suggestedPerson : allPossiblePeople) {
				suggestion.add(suggestedPerson);
				for (Player player : Board.getInstance().getPlayerQueue()) {
					if (player.getPlayerName().trim().equals(suggestedPerson.getCardName().trim())) {
						this.moveToLocation(player);
					}
				}
			}
		}
		// if there are multiple people left, randomly select one
		else if (allPossiblePeople.size() > 1){
			Queue<Card> allUnknownPeople = new LinkedList<>();
			allUnknownPeople.addAll(allPossiblePeople);

			while (allUnknownPeople.size() > 1) {
				int randIndex = rand.nextInt(allUnknownPeople.size()); 
				for (int i = 0; i < randIndex; i++) {
					allUnknownPeople.add(allUnknownPeople.remove()); // puts head of queue at back of queue
				}
				allUnknownPeople.remove();
			}
			// adds last random card left in queue
			suggestion.add(allUnknownPeople.peek());
			for (Player player : Board.getInstance().getPlayerQueue()) {
				if (player.getPlayerName().trim().equals(allUnknownPeople.peek().getCardName().trim())) {
					this.moveToLocation(player);
				}
			}

		}

		else {
			//opportunity for refactoring with custom exception later
			System.out.println("Error: There are 0 or less people left");
		}

		for (int i = 0; i < suggestion.size(); i++) {
			suggestionArray[i] = suggestion.get(i);
		}
		return suggestionArray;
	}


	@Override
	public BoardCell selectTarget(Set<BoardCell> targets) {

		boolean targetsContainRoom = false;
		Set<Card> allRoomsKnown = super.getSeenRoom();
		allRoomsKnown.addAll(super.getPlayerCards());
		// for each target
		for (BoardCell potentialTarget : targets) {

			// if the target is a room
			if (potentialTarget.isARoom()) {
				targetsContainRoom = true;
				Boolean roomHasBeenSeen = false;
				// see if the room has been seen before
				for (Card targetRoom : allRoomsKnown) {
					// if the card matches the room
					if (Board.getInstance().getRoomMap().get(potentialTarget.getInitial()).getName().equals(targetRoom.getCardName())) {
						roomHasBeenSeen = true;
						continue;
					}

				}
				// if card hasn't been seen, choose as target
				if (!roomHasBeenSeen && !potentialTarget.isOccupied()) {
					potentialTarget.setOccupied(true);
					return potentialTarget;
				}
			}
		}

		// target has no rooms it needs to enter... randomly select a target
		Random rand = new Random(); 
		Queue<BoardCell> hallwayQueue = new LinkedList<>();

		//build queue of hallway BoardCells
		for (BoardCell potentialTarget : targets) {
			if (!potentialTarget.isARoom()) {
				hallwayQueue.add(potentialTarget);
			}

		}
		// randomly choose hallway Target
		while (hallwayQueue.size() > 1) {
			int randIndex = rand.nextInt(hallwayQueue.size()); 
			for (int i = 0; i < randIndex; i++) {
				hallwayQueue.add(hallwayQueue.remove()); // puts head of queue at back of queue
			}
			hallwayQueue.remove();
		}


		return hallwayQueue.peek();
	}


	//always returns false because this is a computer player
	@Override
	public Boolean isHumanPlayer() {
		return false;
	}


	//checks to see if accusation can be made
	public boolean canAccuse() {
		int accusationSize = 3;
		int handSize = 3;

		//returns true if the difference between the deck and the sum of hand and seen cards is 3 (enough for accusation)
		if((Board.getInstance().getDeck().size() - super.getSeenCards().size() - handSize) == accusationSize) {
			return true;
		}
		return false;
	}



}
