/**
 * 
 */
/**
 * @author calla
 *
 */
module ClueGame {
	requires junit;
	requires org.junit.jupiter.api;
	requires java.desktop;
}