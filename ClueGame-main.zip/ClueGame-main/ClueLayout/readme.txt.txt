Team members: Calla Winner and Scott Williams

The one required walkway with a door that must be adjacent to more than one room is located at cell B18